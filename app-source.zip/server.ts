import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI, Type } from "@google/genai";
import dotenv from "dotenv";

dotenv.config();

const app = express();
const PORT = 3000;

app.use(express.json({ limit: "10mb" }));

// Initialize Gemini Client
const ai = new GoogleGenAI({
  apiKey: process.env.GEMINI_API_KEY,
  httpOptions: {
    headers: {
      "User-Agent": "aistudio-build",
    },
  },
});

// Download Zip Endpoint for Exporting Source Code
app.get("/api/download-zip", (_req, res) => {
  const zipPath = path.join(process.cwd(), "app-source.zip");
  res.download(zipPath, "store-wallet-source.zip", (err) => {
    if (err && !res.headersSent) {
      res.status(404).json({ error: "ملف ZIP غير متوفر حالياً" });
    }
  });
});

// Health check endpoint
app.get("/api/health", (_req, res) => {
  res.json({ status: "ok", service: "Store Wallet & Branch Accounting Server" });
});

// In-memory store for incoming webhook SMS messages
const incomingWebhookSmsQueue: any[] = [];

/**
 * Background SMS Webhook Endpoint
 * Allows Android SMS Forwarders (like SMS Forwarder / Tasker / MacroDroid) or Capacitor background services
 * to forward incoming SMS messages in real-time in the background without user intervention.
 */
app.post("/api/webhook/sms", (req, res) => {
  try {
    const { from, senderId, text, body, message, secretToken, branchId } = req.body;
    const smsContent = text || body || message || "";
    const sender = senderId || from || "jaib";

    if (!smsContent) {
      return res.status(400).json({ success: false, error: "لم يتم استقبال نص الرسالة" });
    }

    const newRecord = {
      id: "wh-" + Date.now() + "-" + Math.floor(Math.random() * 1000),
      rawSmsText: smsContent,
      senderId: String(sender).toLowerCase(),
      branchId: branchId || undefined,
      receivedAt: new Date().toISOString(),
    };

    incomingWebhookSmsQueue.unshift(newRecord);
    if (incomingWebhookSmsQueue.length > 100) {
      incomingWebhookSmsQueue.pop();
    }

    console.log("Received Background SMS via Webhook:", newRecord);

    return res.json({
      success: true,
      message: "تم استقبال الرسالة النصية في الخلفية بنجاح",
      record: newRecord,
    });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message });
  }
});

// Endpoint to fetch pending background SMS messages for sync
app.get("/api/webhook/sms", (_req, res) => {
  res.json({
    success: true,
    count: incomingWebhookSmsQueue.length,
    messages: incomingWebhookSmsQueue,
  });
});

/**
 * AI SMS & Screenshot Parsing API Endpoint
 * Accepts raw text or base64 image (SMS notification screenshot)
 */
app.post("/api/parse-sms", async (req, res) => {
  try {
    const { smsText, imageBase64, mimeType, senderId } = req.body;

    if (!smsText && !imageBase64) {
      return res.status(400).json({ error: "الرجاء تزويد نص الرسالة أو صورة الإشعار" });
    }

    const systemInstruction = `أنت خبير محاسبي متقدم في تحليل وقراءة إشعارات التحويلات والمحافظ المالية اليمنية والعربية (مثل محفظة جيب jaib، حاسب الكريمي Kuraimi، جوالي Jawali، وان كاش OneCash، فلوسك Floosak، تضامن باي، بنك الكرد، ام فلوس).
وظيفتك هي استخراج بيانات تحويل الأموال بدقة متناهية من النص أو الصورة وإرجاعها ككائن JSON بالصيغة المحددة.
تأكد من تنظيف المبالغ وأرقام العمليات وإزالة الشوائب. العملة الافتراضية هي YER (ريال يمني) إلا إذا ذُكر دولار USD أو سعودي SAR.`;

    const promptText = `قم بتحليل إشعار الحوالة التالي واستخرج منه التفاصيل بشكل دقيق جداً:
اسم المرسل المطلوب تتبعه: "${senderId || 'عام'}"
نص الإشعار: "${smsText || 'راجع الصورة المرفقة'}"

المطلوب استخراج:
- transferRefNumber: رقم العملية أو المرجع أو رقم الحوالة (سلسلة نصية خالية من الفواصل).
- amount: قيمة المبلغ كرقم فقط (مثال: 45000).
- currency: YER أو SAR أو USD.
- senderCustomerName: اسم العميل المحول أو صاحب الحساب إن وجد في الرسالة.
- customerPhone: رقم هاتف المحول إذا ذكر في الرسالة.
- providerName: اسم المحفظة أو البنك (مثال: محفظة جيب، حاسب الكريمي، جوالي، وان كاش).
- confidenceScore: نسبة دقة التحليل من 1 إلى 100.`;

    const contents: any[] = [];

    if (imageBase64) {
      contents.push({
        inlineData: {
          mimeType: mimeType || "image/png",
          data: imageBase64.replace(/^data:image\/\w+;base64,/, ""),
        },
      });
    }

    contents.push({ text: promptText });

    const response = await ai.models.generateContent({
      model: "gemini-3.6-flash",
      contents,
      config: {
        systemInstruction,
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            transferRefNumber: { type: Type.STRING, description: "رقم العملية أو المرجع" },
            amount: { type: Type.NUMBER, description: "المبلغ بالأرقام" },
            currency: { type: Type.STRING, description: "العملة YER or SAR or USD" },
            senderCustomerName: { type: Type.STRING, description: "اسم المحول" },
            customerPhone: { type: Type.STRING, description: "رقم الهاتف" },
            providerName: { type: Type.STRING, description: "اسم المحفظة أو البنك" },
            confidenceScore: { type: Type.NUMBER, description: "درجة الثقة 0-100" },
          },
          required: ["transferRefNumber", "amount", "currency", "providerName"],
        },
      },
    });

    const parsedJson = JSON.parse(response.text || "{}");

    res.json({
      success: true,
      data: parsedJson,
    });
  } catch (error: any) {
    console.error("AI SMS Parse Error:", error);
    res.status(500).json({
      success: false,
      error: "فشل التحليل الذكي للرسالة عبر AI: " + (error.message || "خطأ غير معروف"),
    });
  }
});

async function startServer() {
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (_req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server listening on http://0.0.0.0:${PORT}`);
  });
}

startServer();
