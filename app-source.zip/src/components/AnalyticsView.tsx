import React from 'react';
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
  Legend,
} from 'recharts';
import { BarChart3, PieChart as PieChartIcon, TrendingUp, Building2, Wallet } from 'lucide-react';
import { Branch, SMSTransaction } from '../types';
import { formatCurrency } from '../utils/smsParser';

interface AnalyticsViewProps {
  transactions: SMSTransaction[];
  branches: Branch[];
}

const COLORS = ['#10b981', '#3b82f6', '#f59e0b', '#8b5cf6', '#ec4899', '#06b6d4'];

export const AnalyticsView: React.FC<AnalyticsViewProps> = ({ transactions, branches }) => {
  // 1. Branch Deposits Breakdown Data for Bar Chart
  const branchChartData = branches.map((b) => {
    const bTxs = transactions.filter((t) => t.branchId === b.id);
    const sum = bTxs.reduce((acc, t) => acc + t.amount, 0);
    return {
      name: b.name.replace('فرع ', ''),
      amount: sum,
      count: bTxs.length,
    };
  });

  // 2. Wallet Provider Distribution Data for Pie Chart
  const providerMap: { [key: string]: number } = {};
  transactions.forEach((tx) => {
    const p = tx.providerName || 'عام';
    providerMap[p] = (providerMap[p] || 0) + tx.amount;
  });

  const providerChartData = Object.keys(providerMap).map((key) => ({
    name: key,
    value: providerMap[key],
  }));

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="bg-white dark:bg-slate-900 p-5 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="p-3 bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 rounded-xl border border-emerald-500/20">
            <BarChart3 className="w-6 h-6" />
          </div>
          <div>
            <h2 className="text-lg font-bold text-slate-900 dark:text-white">
              التقارير والمخططات البيانية لمبيعات الفروع
            </h2>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
              تحليل مرئي لتوزيع الإيداعات والتحويلات المالية حسب المحفظة والفرع.
            </p>
          </div>
        </div>
      </div>

      {/* Charts Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        
        {/* Branch Comparison Bar Chart */}
        <div className="bg-white dark:bg-slate-900 p-5 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm space-y-4">
          <h3 className="font-bold text-sm text-slate-900 dark:text-white flex items-center gap-2">
            <Building2 className="w-4 h-4 text-emerald-500" />
            مقارنة الإيداعات والمبيعات بين الفروع (بالريال):
          </h3>

          <div className="h-64 text-xs">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={branchChartData}>
                <XAxis dataKey="name" stroke="#888888" fontSize={10} tickLine={false} />
                <YAxis stroke="#888888" fontSize={10} tickLine={false} />
                <Tooltip
                  formatter={(value: any) => [formatCurrency(Number(value)), 'المبلغ']}
                  contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155', color: '#fff', fontSize: '11px', borderRadius: '8px' }}
                />
                <Bar dataKey="amount" fill="#10b981" radius={[6, 6, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Wallet Provider Pie Chart */}
        <div className="bg-white dark:bg-slate-900 p-5 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm space-y-4">
          <h3 className="font-bold text-sm text-slate-900 dark:text-white flex items-center gap-2">
            <Wallet className="w-4 h-4 text-blue-500" />
            توزيع التحويلات حسب مرسلي المحافظ (جيب، الكريمي، جوالي...):
          </h3>

          <div className="h-64 text-xs">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={providerChartData}
                  cx="50%"
                  cy="50%"
                  innerRadius={60}
                  outerRadius={85}
                  paddingAngle={5}
                  dataKey="value"
                >
                  {providerChartData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip
                  formatter={(value: any) => [formatCurrency(Number(value)), 'المبلغ']}
                  contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155', color: '#fff', fontSize: '11px', borderRadius: '8px' }}
                />
                <Legend />
              </PieChart>
            </ResponsiveContainer>
          </div>
        </div>

      </div>
    </div>
  );
};
