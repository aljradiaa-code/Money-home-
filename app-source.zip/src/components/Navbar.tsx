import React from 'react';
import {
  Wallet,
  Building2,
  Bell,
  CheckCircle2,
  Clock,
  PlusCircle,
  FileText,
  Camera,
  Lock,
  BarChart3,
  Settings,
  Layers,
  Sparkles,
} from 'lucide-react';
import { SMSTransaction } from '../types';
import { formatCurrency } from '../utils/smsParser';

interface NavbarProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
  transactions: SMSTransaction[];
  onOpenSimulateModal: () => void;
  onOpenPasteModal: () => void;
  onOpenScanModal: () => void;
  onOpenReconciliationModal: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  activeTab,
  setActiveTab,
  transactions,
  onOpenSimulateModal,
  onOpenPasteModal,
  onOpenScanModal,
  onOpenReconciliationModal,
}) => {
  const unassignedTxs = transactions.filter((t) => t.status === 'UNASSIGNED');
  const assignedTxs = transactions.filter((t) => t.status === 'ASSIGNED');

  const totalUnassignedAmount = unassignedTxs.reduce((sum, t) => sum + t.amount, 0);
  const totalAssignedAmount = assignedTxs.reduce((sum, t) => sum + t.amount, 0);
  const totalTodayAmount = transactions.reduce((sum, t) => sum + t.amount, 0);

  const todayDateStr = new Date().toLocaleDateString('ar-YE', {
    weekday: 'long',
    year: 'numeric',
    month: 'long',
    day: 'numeric',
  });

  return (
    <header className="bg-slate-900 text-white border-b border-slate-800 sticky top-0 z-40 shadow-lg">
      {/* Top Banner / Portfolio Overview */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-3.5">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
          
          {/* Brand & Date */}
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-xl bg-gradient-to-tr from-emerald-600 to-teal-400 flex items-center justify-center shadow-lg shadow-emerald-900/30 ring-2 ring-emerald-500/20">
              <Wallet className="w-6 h-6 text-white" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-xl font-bold tracking-tight text-white font-sans">
                  حافظتي <span className="text-emerald-400 text-sm font-normal">| المحاسب الذكي للفروع</span>
                </h1>
                <span className="bg-emerald-500/10 text-emerald-400 text-xs px-2 py-0.5 rounded-full border border-emerald-500/20 font-medium">
                  مباشر
                </span>
              </div>
              <p className="text-xs text-slate-400 mt-0.5 flex items-center gap-1.5">
                <span>{todayDateStr}</span>
                <span className="inline-block w-1 h-1 rounded-full bg-slate-600"></span>
                <span>إدارة تحويلات المحافظ الإلكترونية</span>
              </p>
            </div>
          </div>

          {/* Quick Realtime Portfolio Counters */}
          <div className="grid grid-cols-3 gap-2 sm:gap-3 bg-slate-800/80 p-2 rounded-xl border border-slate-700/60">
            {/* Total Wallet Receipts */}
            <div className="px-3 py-1.5 rounded-lg bg-slate-900/50">
              <p className="text-[11px] text-slate-400 font-medium flex items-center gap-1">
                <Wallet className="w-3 h-3 text-emerald-400" />
                إجمالي إيداعات اليوم
              </p>
              <p className="text-sm sm:text-base font-bold text-emerald-400 mt-0.5">
                {formatCurrency(totalTodayAmount)}
              </p>
            </div>

            {/* Assigned to Branches */}
            <div className="px-3 py-1.5 rounded-lg bg-slate-900/50">
              <p className="text-[11px] text-slate-400 font-medium flex items-center gap-1">
                <CheckCircle2 className="w-3 h-3 text-blue-400" />
                المقيدة للفروع ({assignedTxs.length})
              </p>
              <p className="text-sm sm:text-base font-bold text-blue-400 mt-0.5">
                {formatCurrency(totalAssignedAmount)}
              </p>
            </div>

            {/* Unassigned / Pending Queue */}
            <div className={`px-3 py-1.5 rounded-lg transition-all ${unassignedTxs.length > 0 ? 'bg-amber-500/10 border border-amber-500/30 animate-pulse' : 'bg-slate-900/50'}`}>
              <p className="text-[11px] font-medium flex items-center gap-1 text-amber-400">
                <Clock className="w-3 h-3 text-amber-400" />
                معلقة - غير مقيدة ({unassignedTxs.length})
              </p>
              <p className="text-sm sm:text-base font-bold text-amber-400 mt-0.5">
                {formatCurrency(totalUnassignedAmount)}
              </p>
            </div>
          </div>

          {/* Action Tools */}
          <div className="flex items-center gap-2 flex-wrap sm:flex-nowrap">
            <button
              onClick={onOpenSimulateModal}
              className="flex-1 sm:flex-initial flex items-center justify-center gap-1.5 px-3 py-2 bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold rounded-lg shadow-sm transition-all hover:shadow-emerald-600/30 active:scale-95"
            >
              <PlusCircle className="w-4 h-4" />
              <span>محاكاة وصول رسالة</span>
            </button>

            <button
              onClick={onOpenPasteModal}
              className="flex-1 sm:flex-initial flex items-center justify-center gap-1.5 px-3 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-medium rounded-lg border border-slate-700 transition-all hover:border-slate-600 active:scale-95"
            >
              <FileText className="w-4 h-4 text-emerald-400" />
              <span>لصق رسالة نصية</span>
            </button>

            <button
              onClick={onOpenScanModal}
              className="flex-1 sm:flex-initial flex items-center justify-center gap-1.5 px-3 py-2 bg-indigo-900/40 hover:bg-indigo-900/60 text-indigo-200 text-xs font-medium rounded-lg border border-indigo-700/50 transition-all active:scale-95"
            >
              <Camera className="w-4 h-4 text-indigo-400" />
              <span>مسح صورة (AI)</span>
            </button>

            <button
              onClick={onOpenReconciliationModal}
              className="flex-1 sm:flex-initial flex items-center justify-center gap-1.5 px-3 py-2 bg-slate-800 hover:bg-rose-950/40 hover:text-rose-300 text-slate-300 text-xs font-medium rounded-lg border border-slate-700 transition-all active:scale-95"
            >
              <Lock className="w-4 h-4 text-rose-400" />
              <span>إغلاق اليومية</span>
            </button>
          </div>

        </div>
      </div>

      {/* Main Navigation Tabs */}
      <div className="bg-slate-950 border-t border-slate-800/80">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <nav className="flex space-x-1 space-x-reverse overflow-x-auto py-2 scrollbar-none">
            <button
              onClick={() => setActiveTab('dashboard')}
              className={`flex items-center gap-2 px-3.5 py-2 rounded-lg text-xs font-medium whitespace-nowrap transition-all ${
                activeTab === 'dashboard'
                  ? 'bg-emerald-600 text-white shadow-md shadow-emerald-900/30 font-semibold'
                  : 'text-slate-400 hover:text-white hover:bg-slate-800/60'
              }`}
            >
              <Layers className="w-4 h-4" />
              <span>لوحة التحكم المباشرة</span>
              {unassignedTxs.length > 0 && (
                <span className="bg-amber-500 text-slate-950 text-[10px] font-bold px-1.5 py-0.2 rounded-full">
                  {unassignedTxs.length}
                </span>
              )}
            </button>

            <button
              onClick={() => setActiveTab('unassigned')}
              className={`flex items-center gap-2 px-3.5 py-2 rounded-lg text-xs font-medium whitespace-nowrap transition-all ${
                activeTab === 'unassigned'
                  ? 'bg-amber-600 text-white shadow-md font-semibold'
                  : 'text-slate-400 hover:text-white hover:bg-slate-800/60'
              }`}
            >
              <Bell className="w-4 h-4" />
              <span>صندوق الحوالات المعلقة</span>
              {unassignedTxs.length > 0 && (
                <span className="bg-amber-400 text-amber-950 text-[10px] font-extrabold px-1.5 py-0.2 rounded-full">
                  {unassignedTxs.length}
                </span>
              )}
            </button>

            <button
              onClick={() => setActiveTab('branches')}
              className={`flex items-center gap-2 px-3.5 py-2 rounded-lg text-xs font-medium whitespace-nowrap transition-all ${
                activeTab === 'branches'
                  ? 'bg-emerald-600 text-white shadow-md font-semibold'
                  : 'text-slate-400 hover:text-white hover:bg-slate-800/60'
              }`}
            >
              <Building2 className="w-4 h-4" />
              <span>فروع المحلات ودواتر الأستاذ</span>
            </button>

            <button
              onClick={() => setActiveTab('all_transactions')}
              className={`flex items-center gap-2 px-3.5 py-2 rounded-lg text-xs font-medium whitespace-nowrap transition-all ${
                activeTab === 'all_transactions'
                  ? 'bg-emerald-600 text-white shadow-md font-semibold'
                  : 'text-slate-400 hover:text-white hover:bg-slate-800/60'
              }`}
            >
              <FileText className="w-4 h-4" />
              <span>السجل العام للحوالات</span>
            </button>

            <button
              onClick={() => setActiveTab('reconciliation')}
              className={`flex items-center gap-2 px-3.5 py-2 rounded-lg text-xs font-medium whitespace-nowrap transition-all ${
                activeTab === 'reconciliation'
                  ? 'bg-emerald-600 text-white shadow-md font-semibold'
                  : 'text-slate-400 hover:text-white hover:bg-slate-800/60'
              }`}
            >
              <CheckCircle2 className="w-4 h-4" />
              <span>مطابقة وتقفيل اليومية</span>
            </button>

            <button
              onClick={() => setActiveTab('analytics')}
              className={`flex items-center gap-2 px-3.5 py-2 rounded-lg text-xs font-medium whitespace-nowrap transition-all ${
                activeTab === 'analytics'
                  ? 'bg-emerald-600 text-white shadow-md font-semibold'
                  : 'text-slate-400 hover:text-white hover:bg-slate-800/60'
              }`}
            >
              <BarChart3 className="w-4 h-4" />
              <span>التقارير البيانية</span>
            </button>

            <button
              onClick={() => setActiveTab('settings')}
              className={`flex items-center gap-2 px-3.5 py-2 rounded-lg text-xs font-medium whitespace-nowrap transition-all ${
                activeTab === 'settings'
                  ? 'bg-emerald-600 text-white shadow-md font-semibold'
                  : 'text-slate-400 hover:text-white hover:bg-slate-800/60'
              }`}
            >
              <Settings className="w-4 h-4" />
              <span>إعدادات مرسلي الرسائل والفروع</span>
            </button>
          </nav>
        </div>
      </div>
    </header>
  );
};
