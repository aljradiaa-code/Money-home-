import React, { useState } from 'react';
import {
  Search,
  Filter,
  Download,
  Printer,
  CheckCircle2,
  Clock,
  ArrowRightLeft,
  Building2,
  Trash2,
  Copy,
  Check,
  FileSpreadsheet,
} from 'lucide-react';
import { Branch, SMSTransaction } from '../types';
import { formatCurrency } from '../utils/smsParser';

interface TransactionsTableProps {
  transactions: SMSTransaction[];
  branches: Branch[];
  onAssignBranch: (transactionId: string, branchId: string, notes?: string) => void;
  onDeleteTransaction: (id: string) => void;
  onExportCSV: () => void;
}

export const TransactionsTable: React.FC<TransactionsTableProps> = ({
  transactions,
  branches,
  onAssignBranch,
  onDeleteTransaction,
  onExportCSV,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState('ALL');
  const [branchFilter, setBranchFilter] = useState('ALL');
  const [providerFilter, setProviderFilter] = useState('ALL');
  const [copiedId, setCopiedId] = useState<string | null>(null);

  const filteredTransactions = transactions.filter((tx) => {
    const matchesSearch =
      tx.transferRefNumber.toLowerCase().includes(searchQuery.toLowerCase()) ||
      tx.amount.toString().includes(searchQuery) ||
      (tx.senderCustomerName && tx.senderCustomerName.toLowerCase().includes(searchQuery.toLowerCase())) ||
      (tx.branchName && tx.branchName.toLowerCase().includes(searchQuery.toLowerCase())) ||
      tx.rawSmsText.toLowerCase().includes(searchQuery.toLowerCase());

    const matchesStatus =
      statusFilter === 'ALL' ||
      (statusFilter === 'ASSIGNED' && tx.status === 'ASSIGNED') ||
      (statusFilter === 'UNASSIGNED' && tx.status === 'UNASSIGNED');

    const matchesBranch =
      branchFilter === 'ALL' || tx.branchId === branchFilter;

    const matchesProvider =
      providerFilter === 'ALL' || tx.senderId.toLowerCase() === providerFilter.toLowerCase();

    return matchesSearch && matchesStatus && matchesBranch && matchesProvider;
  });

  const handleCopy = (txt: string) => {
    navigator.clipboard.writeText(txt);
    setCopiedId(txt);
    setTimeout(() => setCopiedId(null), 2000);
  };

  return (
    <div className="space-y-5">
      {/* Search and Filters Bar */}
      <div className="bg-white dark:bg-slate-900 p-4 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm space-y-3">
        <div className="flex flex-col md:flex-row items-stretch md:items-center justify-between gap-3">
          
          {/* Search Box */}
          <div className="relative flex-1">
            <Search className="w-4 h-4 text-slate-400 absolute right-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder="ابحث برقم العملية، اسم الفرع، المحول، أو المبلغ..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pr-9 pl-3 py-2 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl focus:ring-2 focus:ring-emerald-500 text-slate-800 dark:text-slate-100"
            />
          </div>

          {/* Export Button */}
          <button
            onClick={onExportCSV}
            className="flex items-center justify-center gap-1.5 px-3.5 py-2 bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs rounded-xl shadow-sm transition-all"
          >
            <FileSpreadsheet className="w-4 h-4" />
            <span>تصدير اكسل (CSV)</span>
          </button>
        </div>

        {/* Filters Row */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 pt-2 border-t border-slate-100 dark:border-slate-800 text-xs">
          {/* Status Filter */}
          <div className="flex items-center gap-2">
            <span className="text-slate-400 shrink-0">الحالة:</span>
            <select
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
              className="w-full p-1.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg text-slate-800 dark:text-slate-100"
            >
              <option value="ALL">جميع الحوالات ({transactions.length})</option>
              <option value="UNASSIGNED">
                غير مقيدة - معلقة ({transactions.filter((t) => t.status === 'UNASSIGNED').length})
              </option>
              <option value="ASSIGNED">
                مقيدة للفروع ({transactions.filter((t) => t.status === 'ASSIGNED').length})
              </option>
            </select>
          </div>

          {/* Branch Filter */}
          <div className="flex items-center gap-2">
            <span className="text-slate-400 shrink-0">الفرع:</span>
            <select
              value={branchFilter}
              onChange={(e) => setBranchFilter(e.target.value)}
              className="w-full p-1.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg text-slate-800 dark:text-slate-100"
            >
              <option value="ALL">جميع الفروع</option>
              {branches.map((b) => (
                <option key={b.id} value={b.id}>
                  {b.name}
                </option>
              ))}
            </select>
          </div>

          {/* Provider Filter */}
          <div className="flex items-center gap-2">
            <span className="text-slate-400 shrink-0">المحفظة:</span>
            <select
              value={providerFilter}
              onChange={(e) => setProviderFilter(e.target.value)}
              className="w-full p-1.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg text-slate-800 dark:text-slate-100"
            >
              <option value="ALL">جميع مرسلي المحافظ</option>
              <option value="jaib">jaib (جيب)</option>
              <option value="kuraimi">kuraimi (الكريمي)</option>
              <option value="jawali">jawali (جوالي)</option>
              <option value="onecash">onecash (وان كاش)</option>
              <option value="floosak">floosak (فلوسك)</option>
            </select>
          </div>
        </div>
      </div>

      {/* Main Transactions Table */}
      <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-xs text-right">
            <thead className="bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 font-bold border-b border-slate-200 dark:border-slate-700">
              <tr>
                <th className="p-3">#</th>
                <th className="p-3">رقم العملية / المرجع</th>
                <th className="p-3">المحفظة</th>
                <th className="p-3">المبلغ الإجمالي</th>
                <th className="p-3">اسم المحول</th>
                <th className="p-3">الفرع المقيد له</th>
                <th className="p-3">تاريخ ووقت الرسالة</th>
                <th className="p-3">الحالة</th>
                <th className="p-3 text-center">إجراءات</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
              {filteredTransactions.length === 0 ? (
                <tr>
                  <td colSpan={9} className="p-8 text-center text-slate-400">
                    لا توجد أي حوالات تطابق معايير البحث الحالية.
                  </td>
                </tr>
              ) : (
                filteredTransactions.map((tx, idx) => (
                  <tr key={tx.id} className="hover:bg-slate-50 dark:hover:bg-slate-800/50 transition-colors">
                    <td className="p-3 font-bold text-slate-400">{idx + 1}</td>

                    <td className="p-3 font-mono font-bold text-slate-900 dark:text-white flex items-center gap-1">
                      <span>{tx.transferRefNumber}</span>
                      <button
                        onClick={() => handleCopy(tx.transferRefNumber)}
                        className="text-slate-400 hover:text-emerald-500 p-0.5"
                      >
                        {copiedId === tx.transferRefNumber ? (
                          <Check className="w-3 h-3 text-emerald-500" />
                        ) : (
                          <Copy className="w-3 h-3" />
                        )}
                      </button>
                    </td>

                    <td className="p-3">
                      <span className="bg-slate-100 dark:bg-slate-800 px-2 py-0.5 rounded text-slate-700 dark:text-slate-300 font-medium">
                        {tx.providerName}
                      </span>
                    </td>

                    <td className="p-3 font-black text-emerald-600 dark:text-emerald-400 text-sm">
                      {formatCurrency(tx.amount, tx.currency)}
                    </td>

                    <td className="p-3">{tx.senderCustomerName || 'عام'}</td>

                    {/* Branch Cell / Reassign Dropdown */}
                    <td className="p-3">
                      <select
                        value={tx.branchId || ''}
                        onChange={(e) => onAssignBranch(tx.id, e.target.value)}
                        className={`px-2 py-1 text-xs rounded-lg border font-medium ${
                          tx.branchId
                            ? 'bg-emerald-500/10 border-emerald-500/30 text-emerald-700 dark:text-emerald-300'
                            : 'bg-amber-500/10 border-amber-500/30 text-amber-700 dark:text-amber-300'
                        }`}
                      >
                        <option value="">-- غير مقيد (معلق) --</option>
                        {branches.map((b) => (
                          <option key={b.id} value={b.id}>
                            {b.name}
                          </option>
                        ))}
                      </select>
                    </td>

                    <td className="p-3 font-mono text-slate-500 text-[11px]">
                      {tx.formattedDate} - {tx.formattedTime}
                    </td>

                    <td className="p-3">
                      {tx.status === 'ASSIGNED' ? (
                        <span className="inline-flex items-center gap-1 text-emerald-600 dark:text-emerald-400 font-bold text-[11px]">
                          <CheckCircle2 className="w-3.5 h-3.5" /> مقيدة
                        </span>
                      ) : (
                        <span className="inline-flex items-center gap-1 text-amber-600 dark:text-amber-400 font-bold text-[11px] animate-pulse">
                          <Clock className="w-3.5 h-3.5" /> معلقة
                        </span>
                      )}
                    </td>

                    <td className="p-3 text-center">
                      <button
                        onClick={() => onDeleteTransaction(tx.id)}
                        className="p-1.5 text-slate-400 hover:text-rose-600 hover:bg-rose-50 dark:hover:bg-rose-950/30 rounded-lg transition-colors"
                        title="حذف الحوالة"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
