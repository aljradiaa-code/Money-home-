import React, { useState } from 'react';
import {
  Lock,
  CheckCircle2,
  AlertTriangle,
  Printer,
  Building2,
  Wallet,
  Calendar,
  FileCheck,
  RotateCcw,
  ShieldCheck,
} from 'lucide-react';
import { Branch, DailyCloseout, SMSTransaction } from '../types';
import { formatCurrency } from '../utils/smsParser';

interface ReconciliationViewProps {
  transactions: SMSTransaction[];
  branches: Branch[];
  closeouts: DailyCloseout[];
  onExecuteDailyCloseout: (notes: string) => void;
  onOpenPrintReport: () => void;
}

export const ReconciliationView: React.FC<ReconciliationViewProps> = ({
  transactions,
  branches,
  closeouts,
  onExecuteDailyCloseout,
  onOpenPrintReport,
}) => {
  const [closeoutNotes, setCloseoutNotes] = useState('');
  const [isLockedToday, setIsLockedToday] = useState(false);

  const unassigned = transactions.filter((t) => t.status === 'UNASSIGNED');
  const assigned = transactions.filter((t) => t.status === 'ASSIGNED');

  const totalWalletToday = transactions.reduce((sum, t) => sum + t.amount, 0);
  const totalAssignedToday = assigned.reduce((sum, t) => sum + t.amount, 0);
  const totalUnassignedToday = unassigned.reduce((sum, t) => sum + t.amount, 0);

  const isReconciled = unassigned.length === 0;

  const handleCloseDay = () => {
    onExecuteDailyCloseout(closeoutNotes);
    setIsLockedToday(true);
  };

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="bg-white dark:bg-slate-900 p-5 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="flex items-start gap-3.5">
          <div className="p-3 bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 rounded-xl border border-emerald-500/20 shrink-0">
            <Lock className="w-6 h-6" />
          </div>
          <div>
            <h2 className="text-lg font-bold text-slate-900 dark:text-white flex items-center gap-2">
              مطابقة وتقفيل اليومية للمحفظة المالية
              {isReconciled ? (
                <span className="bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 text-xs px-2.5 py-0.5 rounded-full font-bold border border-emerald-500/30">
                  متطابقة 100%
                </span>
              ) : (
                <span className="bg-amber-500/10 text-amber-600 dark:text-amber-400 text-xs px-2.5 py-0.5 rounded-full font-bold border border-amber-500/30">
                  توجد حوالات معلقة
                </span>
              )}
            </h2>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
              مراجعة نهاية اليوم: التأكد من توزيع كافة الحوالات الواردة للمحفظة على حسابات الفروع وإغلاق السجل اليومي.
            </p>
          </div>
        </div>

        <button
          onClick={onOpenPrintReport}
          className="shrink-0 flex items-center justify-center gap-2 px-4 py-2.5 bg-slate-900 hover:bg-slate-800 text-white font-bold text-xs rounded-xl shadow-md transition-all border border-slate-700"
        >
          <Printer className="w-4 h-4 text-emerald-400" />
          <span>معاينة وطباعة التقرير الشامل</span>
        </button>
      </div>

      {/* Warning Alert if Unassigned Transfers Exist */}
      {!isReconciled && (
        <div className="bg-amber-500/10 border border-amber-500/30 p-4 rounded-2xl flex items-start gap-3 text-amber-800 dark:text-amber-300">
          <AlertTriangle className="w-5 h-5 shrink-0 mt-0.5 text-amber-500" />
          <div className="text-xs space-y-1">
            <h4 className="font-bold">تنبيه قبل إغلاق اليومية!</h4>
            <p className="leading-relaxed">
              توجد حالياً <strong>{unassigned.length} حوالة معلقة</strong> بمبلغ إجمالي قدره{' '}
              <strong>{formatCurrency(totalUnassignedToday)}</strong> لم يتم تقييدها لأي فرع بعد. ينصح بفرزها وتقييدها قبل التقفيل النهائي.
            </p>
          </div>
        </div>
      )}

      {/* Main Comparison Balance Grid */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {/* Total Wallet Receipts */}
        <div className="bg-white dark:bg-slate-900 p-5 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm space-y-2">
          <div className="flex items-center justify-between text-xs text-slate-500 dark:text-slate-400">
            <span>إجمالي المقبوضات في المحفظة</span>
            <Wallet className="w-4 h-4 text-emerald-500" />
          </div>
          <p className="text-2xl font-black text-slate-900 dark:text-white">
            {formatCurrency(totalWalletToday)}
          </p>
          <p className="text-[11px] text-slate-400">
            من إجمالي {transactions.length} إشعار رسالة نصية
          </p>
        </div>

        {/* Total Assigned to Branches */}
        <div className="bg-white dark:bg-slate-900 p-5 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm space-y-2">
          <div className="flex items-center justify-between text-xs text-slate-500 dark:text-slate-400">
            <span>إجمالي المقيد للفروع</span>
            <Building2 className="w-4 h-4 text-blue-500" />
          </div>
          <p className="text-2xl font-black text-blue-600 dark:text-blue-400">
            {formatCurrency(totalAssignedToday)}
          </p>
          <p className="text-[11px] text-slate-400">
            تم توزيعها على {branches.length} فروع
          </p>
        </div>

        {/* Unassigned / Variance */}
        <div className="bg-white dark:bg-slate-900 p-5 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm space-y-2">
          <div className="flex items-center justify-between text-xs text-slate-500 dark:text-slate-400">
            <span>الفارق / المعلق غير المقيد</span>
            <AlertTriangle className="w-4 h-4 text-amber-500" />
          </div>
          <p className={`text-2xl font-black ${totalUnassignedToday > 0 ? 'text-amber-500' : 'text-emerald-500'}`}>
            {formatCurrency(totalUnassignedToday)}
          </p>
          <p className="text-[11px] text-slate-400">
            {totalUnassignedToday > 0 ? 'يتطلب التقييد' : 'لا يوجد أي فارق معلق'}
          </p>
        </div>
      </div>

      {/* Branch Breakdown Audit Table */}
      <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm p-5 space-y-4">
        <h3 className="font-bold text-sm text-slate-900 dark:text-white flex items-center gap-2">
          <Building2 className="w-4 h-4 text-emerald-500" />
          تفصيل توزيع الحوالات المالي اليومي لكل فرع:
        </h3>

        <div className="border border-slate-200 dark:border-slate-800 rounded-xl overflow-hidden">
          <table className="w-full text-xs text-right">
            <thead className="bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 font-bold">
              <tr>
                <th className="p-3">اسم الفرع</th>
                <th className="p-3">المدينة</th>
                <th className="p-3">عدد الحوالات المقيدة</th>
                <th className="p-3">إجمالي مبلغ الفرع</th>
                <th className="p-3">النسبة من إجمالي المحفظة</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
              {branches.map((b) => {
                const branchTxs = transactions.filter((t) => t.branchId === b.id);
                const bSum = branchTxs.reduce((sum, t) => sum + t.amount, 0);
                const pct = totalWalletToday > 0 ? Math.round((bSum / totalWalletToday) * 100) : 0;

                return (
                  <tr key={b.id} className="hover:bg-slate-50 dark:hover:bg-slate-800/50">
                    <td className="p-3 font-bold text-slate-900 dark:text-white">{b.name}</td>
                    <td className="p-3 text-slate-500">{b.city}</td>
                    <td className="p-3 font-mono font-bold">{branchTxs.length} عملية</td>
                    <td className="p-3 font-black text-emerald-600 dark:text-emerald-400">
                      {formatCurrency(bSum)}
                    </td>
                    <td className="p-3">
                      <div className="flex items-center gap-2">
                        <div className="w-24 bg-slate-100 dark:bg-slate-800 h-1.5 rounded-full overflow-hidden">
                          <div className="bg-emerald-500 h-full" style={{ width: `${pct}%` }}></div>
                        </div>
                        <span className="font-bold text-slate-700 dark:text-slate-300">{pct}%</span>
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>

        {/* Lock Day Section */}
        <div className="pt-4 border-t border-slate-100 dark:border-slate-800 space-y-3">
          <label className="block text-xs font-bold text-slate-700 dark:text-slate-300">
            ملاحظات ختام اليومية والاعتماد المحاسبي:
          </label>
          <input
            type="text"
            value={closeoutNotes}
            onChange={(e) => setCloseoutNotes(e.target.value)}
            placeholder="أدخل أي ملاحظات حول اليومية (مثال: تم إغلاق اليومية ومطابقة الحسابات بالكامل)..."
            className="w-full p-2.5 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl"
          />

          <div className="flex items-center justify-between pt-2">
            <span className="text-xs text-slate-500 flex items-center gap-1">
              <ShieldCheck className="w-4 h-4 text-emerald-500" />
              سيتم حفظ قيد الإغلاق في سجل الأرشيف اليومي
            </span>

            <button
              onClick={handleCloseDay}
              className="flex items-center gap-2 px-6 py-2.5 bg-rose-600 hover:bg-rose-500 text-white font-bold text-xs rounded-xl shadow-md transition-all active:scale-95"
            >
              <Lock className="w-4 h-4" />
              <span>إغلاق وترحيل اليومية الحالية</span>
            </button>
          </div>
        </div>

      </div>
    </div>
  );
};
