import React, { useState } from 'react';
import {
  Bell,
  Building2,
  Check,
  Search,
  Filter,
  Copy,
  Clock,
  Sparkles,
  ArrowRightLeft,
  ChevronDown,
  CheckCheck,
  AlertCircle,
  Smartphone,
  Tag,
  Eye,
} from 'lucide-react';
import { Branch, SMSTransaction } from '../types';
import { formatCurrency } from '../utils/smsParser';

interface UnassignedFeedProps {
  unassignedTransactions: SMSTransaction[];
  branches: Branch[];
  onAssignBranch: (transactionId: string, branchId: string, notes?: string) => void;
  onBulkAssignBranch: (transactionIds: string[], branchId: string) => void;
  onSimulateNewSms: () => void;
}

export const UnassignedFeed: React.FC<UnassignedFeedProps> = ({
  unassignedTransactions,
  branches,
  onAssignBranch,
  onBulkAssignBranch,
  onSimulateNewSms,
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedProvider, setSelectedProvider] = useState<string>('ALL');
  const [selectedTxIds, setSelectedTxIds] = useState<string[]>([]);
  const [bulkBranchId, setBulkBranchId] = useState<string>('');
  const [notesState, setNotesState] = useState<{ [key: string]: string }>({});
  const [expandedSmsId, setExpandedSmsId] = useState<string | null>(null);
  const [copiedId, setCopiedId] = useState<string | null>(null);

  const filtered = unassignedTransactions.filter((tx) => {
    const matchesSearch =
      tx.transferRefNumber.toLowerCase().includes(searchTerm.toLowerCase()) ||
      tx.amount.toString().includes(searchTerm) ||
      (tx.senderCustomerName && tx.senderCustomerName.toLowerCase().includes(searchTerm.toLowerCase())) ||
      tx.rawSmsText.toLowerCase().includes(searchTerm.toLowerCase());

    const matchesProvider =
      selectedProvider === 'ALL' || tx.senderId.toLowerCase() === selectedProvider.toLowerCase();

    return matchesSearch && matchesProvider;
  });

  const handleCopyRef = (ref: string) => {
    navigator.clipboard.writeText(ref);
    setCopiedId(ref);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const handleSelectAll = () => {
    if (selectedTxIds.length === filtered.length) {
      setSelectedTxIds([]);
    } else {
      setSelectedTxIds(filtered.map((t) => t.id));
    }
  };

  const handleToggleSelect = (id: string) => {
    if (selectedTxIds.includes(id)) {
      setSelectedTxIds(selectedTxIds.filter((item) => item !== id));
    } else {
      setSelectedTxIds([...selectedTxIds, id]);
    }
  };

  const handleExecuteBulkAssign = () => {
    if (!bulkBranchId || selectedTxIds.length === 0) return;
    onBulkAssignBranch(selectedTxIds, bulkBranchId);
    setSelectedTxIds([]);
    setBulkBranchId('');
  };

  const getProviderBadgeStyle = (senderId: string) => {
    const id = senderId.toLowerCase();
    if (id.includes('jaib')) {
      return 'bg-emerald-500/10 text-emerald-700 dark:text-emerald-400 border-emerald-500/30';
    }
    if (id.includes('kuraimi')) {
      return 'bg-blue-500/10 text-blue-700 dark:text-blue-400 border-blue-500/30';
    }
    if (id.includes('jawali')) {
      return 'bg-indigo-500/10 text-indigo-700 dark:text-indigo-400 border-indigo-500/30';
    }
    if (id.includes('onecash')) {
      return 'bg-amber-500/10 text-amber-700 dark:text-amber-400 border-amber-500/30';
    }
    return 'bg-purple-500/10 text-purple-700 dark:text-purple-400 border-purple-500/30';
  };

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="bg-gradient-to-r from-amber-500/10 via-amber-500/5 to-slate-900/5 p-5 rounded-2xl border border-amber-500/20 shadow-sm flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="flex items-start gap-3.5">
          <div className="p-3 bg-amber-500/20 text-amber-600 dark:text-amber-400 rounded-xl border border-amber-500/30 shrink-0">
            <Bell className="w-6 h-6 animate-bounce" />
          </div>
          <div>
            <h2 className="text-lg font-bold text-slate-900 dark:text-white flex items-center gap-2">
              صندوق الحوالات المعلقة (غير المقيدة للفروع)
              <span className="bg-amber-500 text-slate-950 font-extrabold text-xs px-2.5 py-0.5 rounded-full">
                {unassignedTransactions.length} حوالة
              </span>
            </h2>
            <p className="text-xs text-slate-600 dark:text-slate-300 mt-1 leading-relaxed">
              تصله الرسائل النصية من المحفظة المالية (مثل <span className="font-semibold text-emerald-600 dark:text-emerald-400">jaib</span>، <span className="font-semibold text-blue-600 dark:text-blue-400">Kuraimi</span>، <span className="font-semibold text-indigo-600 dark:text-indigo-400">Jawali</span>) بدون تحديد الفرع. اختر الفرع المناسب بنقرة واحدة لتقييد الحوالة فوراً في حساب الفرع.
            </p>
          </div>
        </div>

        <button
          onClick={onSimulateNewSms}
          className="shrink-0 flex items-center justify-center gap-2 px-4 py-2.5 bg-amber-600 hover:bg-amber-500 text-white font-semibold text-xs rounded-xl shadow-md transition-all active:scale-95"
        >
          <Sparkles className="w-4 h-4" />
          <span>تلقي إشعار رسالة جديدة</span>
        </button>
      </div>

      {/* Filter and Bulk Action Bar */}
      <div className="bg-white dark:bg-slate-900 p-4 rounded-xl border border-slate-200 dark:border-slate-800 shadow-sm space-y-3">
        <div className="flex flex-col md:flex-row items-stretch md:items-center justify-between gap-3">
          
          {/* Search Box */}
          <div className="relative flex-1">
            <Search className="w-4 h-4 text-slate-400 absolute right-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder="ابحث برقم الحوالة، اسم المحول، أو المبلغ..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pr-9 pl-3 py-2 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg focus:outline-none focus:ring-2 focus:ring-amber-500 text-slate-800 dark:text-slate-100"
            />
          </div>

          {/* Provider Filter */}
          <div className="flex items-center gap-2">
            <Filter className="w-4 h-4 text-slate-400 shrink-0" />
            <span className="text-xs text-slate-500 dark:text-slate-400 whitespace-nowrap">اسم المرسل:</span>
            <select
              value={selectedProvider}
              onChange={(e) => setSelectedProvider(e.target.value)}
              className="px-3 py-2 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg focus:outline-none focus:ring-2 focus:ring-amber-500 text-slate-800 dark:text-slate-100"
            >
              <option value="ALL">جميع المرسليين (Jaib, Kuraimi...)</option>
              <option value="jaib">jaib - محفظة جيب</option>
              <option value="kuraimi">kuraimi - حاسب الكريمي</option>
              <option value="jawali">jawali - محفظة جوالي</option>
              <option value="onecash">onecash - وان كاش</option>
              <option value="floosak">floosak - فلوسك</option>
            </select>
          </div>

        </div>

        {/* Bulk Selection Bar */}
        {filtered.length > 0 && (
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-2 pt-2 border-t border-slate-100 dark:border-slate-800">
            <div className="flex items-center gap-2">
              <label className="flex items-center gap-1.5 cursor-pointer text-xs font-medium text-slate-600 dark:text-slate-300">
                <input
                  type="checkbox"
                  checked={selectedTxIds.length > 0 && selectedTxIds.length === filtered.length}
                  onChange={handleSelectAll}
                  className="rounded text-amber-600 focus:ring-amber-500 w-4 h-4"
                />
                تحديد الكل ({filtered.length})
              </label>

              {selectedTxIds.length > 0 && (
                <span className="text-xs font-semibold text-amber-600 dark:text-amber-400 bg-amber-500/10 px-2 py-0.5 rounded-full">
                  تم تحديد {selectedTxIds.length} حوالة
                </span>
              )}
            </div>

            {selectedTxIds.length > 0 && (
              <div className="flex items-center gap-2 w-full sm:w-auto">
                <select
                  value={bulkBranchId}
                  onChange={(e) => setBulkBranchId(e.target.value)}
                  className="flex-1 sm:w-56 px-3 py-1.5 text-xs bg-slate-50 dark:bg-slate-800 border border-amber-300 dark:border-amber-500/40 rounded-lg text-slate-800 dark:text-slate-100"
                >
                  <option value="">-- اختر الفرع للتقييد الجماعي --</option>
                  {branches.map((b) => (
                    <option key={b.id} value={b.id}>
                      {b.name} ({b.city})
                    </option>
                  ))}
                </select>

                <button
                  disabled={!bulkBranchId}
                  onClick={handleExecuteBulkAssign}
                  className="px-3.5 py-1.5 bg-amber-600 hover:bg-amber-500 disabled:bg-slate-300 dark:disabled:bg-slate-800 text-white font-semibold text-xs rounded-lg transition-all"
                >
                  تقييد المحدد
                </button>
              </div>
            )}
          </div>
        )}
      </div>

      {/* Main Unassigned Queue */}
      {filtered.length === 0 ? (
        <div className="bg-white dark:bg-slate-900 p-12 text-center rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm space-y-4">
          <div className="w-16 h-16 bg-emerald-500/10 text-emerald-500 rounded-full flex items-center justify-center mx-auto ring-8 ring-emerald-500/5">
            <CheckCheck className="w-8 h-8" />
          </div>
          <div>
            <h3 className="text-base font-bold text-slate-800 dark:text-slate-100">
              جميع الحوالات مقيدة وموزعة بنجاح!
            </h3>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-1 max-w-md mx-auto">
              لا توجد حالياً أي حوالة معلقة بانتظار التقييد. يمكنك إدخال رسائل جديدة أو محاكاة وصول إشعار من الزر بالأعلى.
            </p>
          </div>
          <button
            onClick={onSimulateNewSms}
            className="inline-flex items-center gap-2 px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white font-semibold text-xs rounded-xl shadow transition-all"
          >
            <Sparkles className="w-4 h-4" />
            <span>محاكاة وصول إشعار تحويل جديد</span>
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 gap-4">
          {filtered.map((tx) => {
            const isSelected = selectedTxIds.includes(tx.id);
            const isExpanded = expandedSmsId === tx.id;

            return (
              <div
                key={tx.id}
                className={`bg-white dark:bg-slate-900 rounded-2xl border transition-all duration-200 shadow-sm hover:shadow-md ${
                  isSelected
                    ? 'border-amber-500 ring-2 ring-amber-500/20 bg-amber-50/30 dark:bg-amber-950/20'
                    : 'border-slate-200 dark:border-slate-800 hover:border-slate-300 dark:hover:border-slate-700'
                }`}
              >
                <div className="p-4 sm:p-5 space-y-4">
                  {/* Top Bar: Checkbox, Provider Tag, Ref #, Amount */}
                  <div className="flex flex-wrap items-center justify-between gap-3 pb-3 border-b border-slate-100 dark:border-slate-800">
                    
                    <div className="flex items-center gap-3">
                      <input
                        type="checkbox"
                        checked={isSelected}
                        onChange={() => handleToggleSelect(tx.id)}
                        className="rounded text-amber-600 focus:ring-amber-500 w-4 h-4 shrink-0"
                      />

                      {/* Provider Badge e.g. jaib */}
                      <div className={`px-2.5 py-1 rounded-lg border text-xs font-bold flex items-center gap-1.5 ${getProviderBadgeStyle(tx.senderId)}`}>
                        <Smartphone className="w-3.5 h-3.5" />
                        <span>{tx.providerName}</span>
                        <span className="text-[10px] opacity-75 font-mono">({tx.senderId})</span>
                      </div>

                      {/* Transfer Ref Number */}
                      <div className="flex items-center gap-1 bg-slate-100 dark:bg-slate-800 px-2.5 py-1 rounded-lg text-xs font-mono font-medium text-slate-700 dark:text-slate-300">
                        <span>رقم العملية:</span>
                        <strong className="text-slate-900 dark:text-white">{tx.transferRefNumber}</strong>
                        <button
                          onClick={() => handleCopyRef(tx.transferRefNumber)}
                          className="p-1 hover:text-emerald-500 transition-colors"
                          title="نسخ رقم العملية"
                        >
                          {copiedId === tx.transferRefNumber ? (
                            <Check className="w-3 h-3 text-emerald-500" />
                          ) : (
                            <Copy className="w-3 h-3" />
                          )}
                        </button>
                      </div>
                    </div>

                    {/* Amount Tag */}
                    <div className="text-left">
                      <span className="text-xs text-slate-500 dark:text-slate-400 block font-medium">المبلغ الإجمالي</span>
                      <span className="text-xl font-black text-emerald-600 dark:text-emerald-400 tracking-tight">
                        {formatCurrency(tx.amount, tx.currency)}
                      </span>
                    </div>

                  </div>

                  {/* Customer & Timestamp Info */}
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-2 text-xs">
                    <div>
                      <span className="text-slate-500 dark:text-slate-400 block">اسم المحول / العميل:</span>
                      <strong className="text-slate-800 dark:text-slate-200">
                        {tx.senderCustomerName || 'غير محدد بالرسالة'}
                      </strong>
                    </div>

                    <div>
                      <span className="text-slate-500 dark:text-slate-400 block">تاريخ ووقت الرسالة:</span>
                      <span className="text-slate-700 dark:text-slate-300 font-mono">
                        {tx.formattedDate} - {tx.formattedTime}
                      </span>
                    </div>

                    <div>
                      <span className="text-slate-500 dark:text-slate-400 block">طريقة التحليل:</span>
                      <span className="inline-flex items-center gap-1 text-emerald-600 dark:text-emerald-400 font-medium">
                        <Sparkles className="w-3 h-3" /> تلقائي دقيق ({tx.confidenceScore}% دقة)
                      </span>
                    </div>
                  </div>

                  {/* Raw SMS Text Toggle */}
                  <div className="bg-slate-50 dark:bg-slate-800/60 p-3 rounded-xl border border-slate-200/80 dark:border-slate-800 text-xs">
                    <div className="flex items-center justify-between">
                      <span className="font-semibold text-slate-700 dark:text-slate-300 flex items-center gap-1.5">
                        <Smartphone className="w-3.5 h-3.5 text-slate-400" />
                        نص إشعار الرسالة النصية الواردة:
                      </span>
                      <button
                        onClick={() => setExpandedSmsId(isExpanded ? null : tx.id)}
                        className="text-amber-600 dark:text-amber-400 hover:underline flex items-center gap-1 text-[11px]"
                      >
                        <Eye className="w-3 h-3" />
                        {isExpanded ? 'إخفاء النص الكامل' : 'عرض النص الكامل'}
                      </button>
                    </div>
                    <p className={`mt-1 text-slate-600 dark:text-slate-300 font-mono text-[11px] leading-relaxed ${isExpanded ? '' : 'line-clamp-2'}`}>
                      "{tx.rawSmsText}"
                    </p>
                  </div>

                  {/* Note / Employee Tag optional input */}
                  <div className="flex items-center gap-2 pt-1">
                    <Tag className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                    <input
                      type="text"
                      placeholder="ملاحظة خاصة بالفرع أو رقم الفاتورة (اختياري)..."
                      value={notesState[tx.id] || ''}
                      onChange={(e) => setNotesState({ ...notesState, [tx.id]: e.target.value })}
                      className="flex-1 px-3 py-1.5 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg focus:outline-none focus:ring-1 focus:ring-amber-500 text-slate-800 dark:text-slate-200"
                    />
                  </div>

                  {/* CORE ACTION: 1-CLICK BRANCH SELECTION & ASSIGNMENT */}
                  <div className="pt-3 border-t border-slate-100 dark:border-slate-800 space-y-2">
                    <span className="text-xs font-bold text-slate-800 dark:text-slate-200 flex items-center gap-1.5">
                      <Building2 className="w-4 h-4 text-emerald-500" />
                      اختر الفرع لتقييد هذه الحوالة فوراً في حسابه:
                    </span>

                    <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-2">
                      {branches.map((b) => (
                        <button
                          key={b.id}
                          onClick={() => onAssignBranch(tx.id, b.id, notesState[tx.id])}
                          className="flex flex-col items-start p-2.5 bg-slate-50 dark:bg-slate-800 hover:bg-emerald-600 hover:text-white text-slate-800 dark:text-slate-200 border border-slate-200 dark:border-slate-700 rounded-xl transition-all duration-150 group shadow-xs active:scale-95 text-right"
                        >
                          <span className="text-xs font-bold group-hover:text-white truncate w-full">
                            {b.name}
                          </span>
                          <span className="text-[10px] text-slate-500 dark:text-slate-400 group-hover:text-emerald-100 mt-0.5">
                            {b.city}
                          </span>
                        </button>
                      ))}
                    </div>
                  </div>

                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};
