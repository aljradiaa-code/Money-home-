import React, { useState } from 'react';
import { X, Camera, Upload, Sparkles, Loader2, Check, Building2 } from 'lucide-react';
import { Branch } from '../types';

interface ScanSmsModalProps {
  isOpen: boolean;
  onClose: () => void;
  branches: Branch[];
  onAddTransactionWithBranch: (
    rawSms: string,
    senderId: string,
    branchId?: string,
    overrideParsed?: any
  ) => void;
}

export const ScanSmsModal: React.FC<ScanSmsModalProps> = ({
  isOpen,
  onClose,
  branches,
  onAddTransactionWithBranch,
}) => {
  const [imagePreview, setImagePreview] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [extractedData, setExtractedData] = useState<any | null>(null);
  const [selectedBranchId, setSelectedBranchId] = useState<string>('');

  if (!isOpen) return null;

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!file.type.startsWith('image/')) {
      setErrorMsg('الرجاء رفع صورة إشعار صالحة (PNG, JPG, WEBP)');
      return;
    }

    setErrorMsg(null);
    setExtractedData(null);

    const reader = new FileReader();
    reader.onload = () => {
      setImagePreview(reader.result as string);
    };
    reader.readAsDataURL(file);
  };

  const handleAnalyzeWithAI = async () => {
    if (!imagePreview) return;

    setLoading(true);
    setErrorMsg(null);

    try {
      const response = await fetch('/api/parse-sms', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          imageBase64: imagePreview,
          mimeType: 'image/png',
          senderId: 'jaib',
        }),
      });

      const resJson = await response.json();

      if (!resJson.success) {
        throw new Error(resJson.error || 'فشل القراءة الذكية للصورة');
      }

      setExtractedData(resJson.data);
    } catch (err: any) {
      setErrorMsg(err.message || 'حدث خطأ أثناء معالجة الصورة عبر AI');
    } finally {
      setLoading(false);
    }
  };

  const handleConfirmAndAdd = () => {
    if (!extractedData) return;

    const rawSms = `إشعار مستخرج من الصورة - المحفظة: ${extractedData.providerName || 'عام'} - رقم العملية: ${extractedData.transferRefNumber} - المبلغ: ${extractedData.amount} - المحول: ${extractedData.senderCustomerName || 'غير محدد'}`;

    onAddTransactionWithBranch(
      rawSms,
      extractedData.providerName?.toLowerCase() || 'jaib',
      selectedBranchId || undefined,
      {
        amount: extractedData.amount,
        transferRefNumber: extractedData.transferRefNumber,
        currency: extractedData.currency || 'YER',
        senderCustomerName: extractedData.senderCustomerName,
        providerName: extractedData.providerName || 'محفظة جيب',
      }
    );

    setImagePreview(null);
    setExtractedData(null);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-xs">
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl w-full max-w-xl shadow-2xl overflow-hidden">
        
        {/* Header */}
        <div className="bg-slate-900 text-white px-6 py-4 flex items-center justify-between border-b border-slate-800">
          <div className="flex items-center gap-2.5">
            <div className="p-2 bg-indigo-500/20 text-indigo-400 rounded-lg">
              <Camera className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-bold text-base">قراءة صورة إشعار الحوالة بالذكاء الاصطناعي (AI OCR)</h3>
              <p className="text-xs text-slate-400">ارفع لقطة شاشة لإشعار التحويل لاستخراج البيانات تلقائياً</p>
            </div>
          </div>
          <button onClick={onClose} className="p-1.5 rounded-lg hover:bg-slate-800 text-slate-400 hover:text-white">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 space-y-4">
          
          {/* Upload Area */}
          {!imagePreview ? (
            <label className="border-2 border-dashed border-slate-300 dark:border-slate-700 hover:border-indigo-500 dark:hover:border-indigo-400 rounded-2xl p-8 flex flex-col items-center justify-center cursor-pointer transition-colors text-center bg-slate-50 dark:bg-slate-800/40">
              <Upload className="w-10 h-10 text-indigo-500 mb-2" />
              <span className="text-xs font-bold text-slate-700 dark:text-slate-200">
                اضغط هنا لاختيار صورة إشعار الرسالة / لقطة الشاشة
              </span>
              <span className="text-[11px] text-slate-400 mt-1">يدعم صور المحافظ (جيب، الكريمي، جوالي، وان كاش...)</span>
              <input type="file" accept="image/*" onChange={handleFileChange} className="hidden" />
            </label>
          ) : (
            <div className="space-y-4">
              <div className="relative rounded-xl overflow-hidden border border-slate-200 dark:border-slate-700 max-h-48 bg-slate-900 flex items-center justify-center">
                <img src={imagePreview} alt="Sms Screenshot" className="object-contain max-h-48" />
                <button
                  onClick={() => {
                    setImagePreview(null);
                    setExtractedData(null);
                  }}
                  className="absolute top-2 left-2 bg-slate-900/80 text-white p-1 rounded-full hover:bg-rose-600"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              {!extractedData && (
                <button
                  disabled={loading}
                  onClick={handleAnalyzeWithAI}
                  className="w-full py-2.5 bg-indigo-600 hover:bg-indigo-500 disabled:bg-slate-400 text-white font-bold text-xs rounded-xl shadow-md transition-all flex items-center justify-center gap-2"
                >
                  {loading ? (
                    <>
                      <Loader2 className="w-4 h-4 animate-spin" />
                      <span>جاري القراءة الذكية واستخراج البيانات عبر Gemini AI...</span>
                    </>
                  ) : (
                    <>
                      <Sparkles className="w-4 h-4" />
                      <span>تحليل الصورة بالذكاء الاصطناعي واستخراج الحوالة</span>
                    </>
                  )}
                </button>
              )}
            </div>
          )}

          {errorMsg && (
            <div className="p-3 bg-rose-500/10 border border-rose-500/30 text-rose-600 dark:text-rose-400 text-xs rounded-xl">
              {errorMsg}
            </div>
          )}

          {/* Extracted JSON Card */}
          {extractedData && (
            <div className="bg-emerald-50 dark:bg-emerald-950/30 p-4 rounded-xl border border-emerald-500/30 space-y-3">
              <div className="flex items-center gap-1.5 text-emerald-800 dark:text-emerald-300 font-bold text-xs">
                <Sparkles className="w-4 h-4 text-emerald-500" />
                تم استخراج البيانات بنجاح من الصورة:
              </div>

              <div className="grid grid-cols-2 gap-2 text-xs">
                <div className="bg-white dark:bg-slate-900 p-2 rounded-lg border border-emerald-500/20">
                  <span className="text-slate-400 block text-[10px]">المبلغ</span>
                  <strong className="text-emerald-600 dark:text-emerald-400 text-sm font-black">
                    {extractedData.amount?.toLocaleString()} {extractedData.currency}
                  </strong>
                </div>

                <div className="bg-white dark:bg-slate-900 p-2 rounded-lg border border-emerald-500/20">
                  <span className="text-slate-400 block text-[10px]">رقم العملية</span>
                  <strong className="font-mono text-slate-800 dark:text-slate-200">
                    {extractedData.transferRefNumber}
                  </strong>
                </div>

                <div className="bg-white dark:bg-slate-900 p-2 rounded-lg border border-emerald-500/20">
                  <span className="text-slate-400 block text-[10px]">المحول / العميل</span>
                  <strong className="text-slate-800 dark:text-slate-200">
                    {extractedData.senderCustomerName || 'غير محدد'}
                  </strong>
                </div>

                <div className="bg-white dark:bg-slate-900 p-2 rounded-lg border border-emerald-500/20">
                  <span className="text-slate-400 block text-[10px]">المحفظة / البنك</span>
                  <strong className="text-slate-800 dark:text-slate-200">
                    {extractedData.providerName || 'عام'}
                  </strong>
                </div>
              </div>

              {/* Branch Assignment Select */}
              <div className="pt-2 border-t border-emerald-500/20">
                <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1 flex items-center gap-1">
                  <Building2 className="w-3.5 h-3.5 text-emerald-500" />
                  اختر الفرع لتقييد هذه الحوالة فوراً:
                </label>
                <select
                  value={selectedBranchId}
                  onChange={(e) => setSelectedBranchId(e.target.value)}
                  className="w-full px-3 py-2 text-xs bg-white dark:bg-slate-900 border border-emerald-500/30 rounded-lg text-slate-800 dark:text-slate-100"
                >
                  <option value="">-- تركها في المعلقة بدون فرع --</option>
                  {branches.map((b) => (
                    <option key={b.id} value={b.id}>
                      {b.name} ({b.city})
                    </option>
                  ))}
                </select>
              </div>

            </div>
          )}

        </div>

        {/* Footer */}
        {extractedData && (
          <div className="bg-slate-50 dark:bg-slate-900 px-6 py-3 border-t border-slate-200 dark:border-slate-800 flex items-center justify-end gap-2">
            <button
              onClick={onClose}
              className="px-4 py-2 text-xs font-medium text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-800 rounded-lg"
            >
              إلغاء
            </button>
            <button
              onClick={handleConfirmAndAdd}
              className="px-5 py-2.5 bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs rounded-xl shadow-md transition-all flex items-center gap-1.5"
            >
              <Check className="w-4 h-4" />
              <span>اعتماد وتقييد الحوالة</span>
            </button>
          </div>
        )}

      </div>
    </div>
  );
};
