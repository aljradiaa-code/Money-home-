import React, { useState } from 'react';
import { X, FileText, CheckCircle2, AlertCircle, ArrowLeftRight, Sparkles } from 'lucide-react';
import { Branch } from '../types';
import { parseSmsText } from '../utils/smsParser';

interface PasteSmsModalProps {
  isOpen: boolean;
  onClose: () => void;
  branches: Branch[];
  onImportParsedSmsList: (items: Array<{ rawSms: string; senderId: string; branchId?: string }>) => void;
}

export const PasteSmsModal: React.FC<PasteSmsModalProps> = ({
  isOpen,
  onClose,
  branches,
  onImportParsedSmsList,
}) => {
  const [rawText, setRawText] = useState('');
  const [defaultSenderId, setDefaultSenderId] = useState('jaib');
  const [defaultBranchId, setDefaultBranchId] = useState('');

  if (!isOpen) return null;

  // Split raw text by empty lines or newline breaks to detect multiple SMS blocks
  const smsBlocks = rawText
    .split(/\n\s*\n|\r\n\s*\r\n/)
    .map((block) => block.trim())
    .filter((block) => block.length > 10);

  const parsedList = smsBlocks.map((block) => {
    const parsed = parseSmsText(block, defaultSenderId);
    return {
      rawSms: block,
      senderId: defaultSenderId,
      branchId: defaultBranchId || undefined,
      parsed,
    };
  });

  const handleImport = () => {
    if (parsedList.length === 0) return;
    onImportParsedSmsList(
      parsedList.map((item) => ({
        rawSms: item.rawSms,
        senderId: item.senderId,
        branchId: item.branchId,
      }))
    );
    setRawText('');
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-xs">
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl w-full max-w-3xl shadow-2xl overflow-hidden max-h-[90vh] flex flex-col">
        
        {/* Header */}
        <div className="bg-slate-900 text-white px-6 py-4 flex items-center justify-between border-b border-slate-800 shrink-0">
          <div className="flex items-center gap-2.5">
            <div className="p-2 bg-emerald-500/20 text-emerald-400 rounded-lg">
              <FileText className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-bold text-base">لصق ومعالجة مجموعة رسائل نصية دفعة واحدة</h3>
              <p className="text-xs text-slate-400">انسخ نص الرسائل من صندوق رسائل الهاتف والصقها هنا</p>
            </div>
          </div>
          <button onClick={onClose} className="p-1.5 rounded-lg hover:bg-slate-800 text-slate-400 hover:text-white">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 overflow-y-auto space-y-5 flex-1">
          
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                اسم مرسل المحفظة (Sender ID):
              </label>
              <select
                value={defaultSenderId}
                onChange={(e) => setDefaultSenderId(e.target.value)}
                className="w-full px-3 py-2 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg text-slate-800 dark:text-slate-100"
              >
                <option value="jaib">jaib - محفظة جيب</option>
                <option value="kuraimi">kuraimi - حاسب الكريمي</option>
                <option value="jawali">jawali - محفظة جوالي</option>
                <option value="onecash">onecash - وان كاش</option>
                <option value="floosak">floosak - فلوسك</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                تقييد لفرع محدد مسبقاً (اختياري):
              </label>
              <select
                value={defaultBranchId}
                onChange={(e) => setDefaultBranchId(e.target.value)}
                className="w-full px-3 py-2 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg text-slate-800 dark:text-slate-100"
              >
                <option value="">-- تركها معلقة لتقييدها لاحقاً --</option>
                {branches.map((b) => (
                  <option key={b.id} value={b.id}>
                    {b.name} ({b.city})
                  </option>
                ))}
              </select>
            </div>
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
              انسخ والصق نصوص الرسائل النصية هنا (افصل بين الرسائل بسطر فارغ):
            </label>
            <textarea
              rows={5}
              value={rawText}
              onChange={(e) => setRawText(e.target.value)}
              placeholder="مثال:&#10;تم إيداع مبلغ 85,000 ريال في حسابكم لدى محفظة جيب. رقم العملية: 98412001...&#10;&#10;إيداع تحويل بمبلغ 120,000 YER. مرجع العملية 45012984..."
              className="w-full p-3 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl font-mono leading-relaxed focus:ring-2 focus:ring-emerald-500 text-slate-800 dark:text-slate-100"
            />
          </div>

          {/* Parsed List Preview Table */}
          {parsedList.length > 0 && (
            <div className="space-y-2">
              <span className="text-xs font-bold text-emerald-600 dark:text-emerald-400 flex items-center gap-1">
                <Sparkles className="w-4 h-4" /> تم استخراج {parsedList.length} حوالة من النصوص الملصقة:
              </span>

              <div className="border border-slate-200 dark:border-slate-800 rounded-xl overflow-hidden max-h-56 overflow-y-auto">
                <table className="w-full text-xs text-right">
                  <thead className="bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 font-bold">
                    <tr>
                      <th className="p-2.5">#</th>
                      <th className="p-2.5">المبلغ</th>
                      <th className="p-2.5">رقم العملية</th>
                      <th className="p-2.5">المحول</th>
                      <th className="p-2.5">الحالة المبدئية</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                    {parsedList.map((item, idx) => (
                      <tr key={idx} className="hover:bg-slate-50 dark:hover:bg-slate-800/50">
                        <td className="p-2.5 font-bold">{idx + 1}</td>
                        <td className="p-2.5 font-bold text-emerald-600 dark:text-emerald-400">
                          {item.parsed.amount.toLocaleString()} {item.parsed.currency}
                        </td>
                        <td className="p-2.5 font-mono">{item.parsed.transferRefNumber}</td>
                        <td className="p-2.5">{item.parsed.senderCustomerName || 'عام'}</td>
                        <td className="p-2.5">
                          {defaultBranchId ? (
                            <span className="text-emerald-600 font-medium">سيتم تقييدها فوراً</span>
                          ) : (
                            <span className="text-amber-600 font-medium">ستنتقل للمعلقة</span>
                          )}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

        </div>

        {/* Footer */}
        <div className="bg-slate-50 dark:bg-slate-900 px-6 py-3 border-t border-slate-200 dark:border-slate-800 flex items-center justify-between shrink-0">
          <span className="text-xs text-slate-500">
            {parsedList.length > 0 ? `جاهز لإدراج ${parsedList.length} حوالة` : 'في انتظار لصق الرسائل'}
          </span>
          <div className="flex items-center gap-2">
            <button
              onClick={onClose}
              className="px-4 py-2 text-xs font-medium text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-800 rounded-lg"
            >
              إلغاء
            </button>
            <button
              disabled={parsedList.length === 0}
              onClick={handleImport}
              className="px-5 py-2.5 bg-emerald-600 hover:bg-emerald-500 disabled:bg-slate-300 dark:disabled:bg-slate-800 text-white font-bold text-xs rounded-xl shadow-md transition-all"
            >
              استيراد وحفظ الحوالات
            </button>
          </div>
        </div>

      </div>
    </div>
  );
};
