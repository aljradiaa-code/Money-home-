import React, { useState } from 'react';
import { X, Smartphone, Sparkles, Send, CheckCircle, RefreshCw } from 'lucide-react';
import { parseSmsText } from '../utils/smsParser';

interface SimulateSmsModalProps {
  isOpen: boolean;
  onClose: () => void;
  onAddTransaction: (rawSms: string, senderId: string) => void;
}

const SMS_TEMPLATES = [
  {
    senderId: 'jaib',
    providerName: 'محفظة جيب (jaib)',
    text: 'تم إيداع مبلغ 95,000 ريال في حسابكم لدى محفظة جيب. رقم العملية: 98412999. المرسل: معرض الأمل للسيارات. التاريخ: 2026/08/07 13:10',
  },
  {
    senderId: 'kuraimi',
    providerName: 'حاسب الكريمي (Kuraimi)',
    text: 'إيداع تحويل بمبلغ 210,000 YER. مرجع العملية 45014880. العميل: مركز السلام الطبي. وقت: 07-08-2026 13:25',
  },
  {
    senderId: 'jawali',
    providerName: 'محفظة جوالي (Jawali)',
    text: 'استلمت مبلغ 135,000 YER بنجاح. رقم الحوالة: 8871900. من: محلات البركة التجارية. 07/08/2026',
  },
  {
    senderId: 'onecash',
    providerName: 'وان كاش (OneCash)',
    text: 'تم استقبال مبلغ 80,000 ريال من رقم 771239988. رقم الإشعار: 334991. المحفظة: OneCash. التاريخ: 2026/08/07 13:40',
  },
  {
    senderId: 'floosak',
    providerName: 'فلوسك (Floosak - BYK)',
    text: 'تم إضافة 175,000 ريال إلى حسابكم عبر محفظة فلوسك. رقم القيد: 772888. التاريخ: 2026-08-07 13:55',
  },
];

export const SimulateSmsModal: React.FC<SimulateSmsModalProps> = ({
  isOpen,
  onClose,
  onAddTransaction,
}) => {
  const [selectedSender, setSelectedSender] = useState('jaib');
  const [smsText, setSmsText] = useState(SMS_TEMPLATES[0].text);
  const [previewParsed, setPreviewParsed] = useState(() => parseSmsText(SMS_TEMPLATES[0].text, 'jaib'));

  if (!isOpen) return null;

  const handleTemplateSelect = (template: typeof SMS_TEMPLATES[0]) => {
    setSelectedSender(template.senderId);
    setSmsText(template.text);
    setPreviewParsed(parseSmsText(template.text, template.senderId));
  };

  const handleTextChange = (text: string) => {
    setSmsText(text);
    setPreviewParsed(parseSmsText(text, selectedSender));
  };

  const handleSenderChange = (sender: string) => {
    setSelectedSender(sender);
    setPreviewParsed(parseSmsText(smsText, sender));
  };

  const handleGenerateRandom = () => {
    const randomAmt = (Math.floor(Math.random() * 30) + 3) * 10000;
    const randomRef = Math.floor(10000000 + Math.random() * 90000000).toString();
    const senders = ['jaib', 'kuraimi', 'jawali', 'onecash'];
    const chosenSender = senders[Math.floor(Math.random() * senders.length)];

    let txt = '';
    if (chosenSender === 'jaib') {
      txt = `تم إيداع مبلغ ${randomAmt.toLocaleString()} ريال في حسابكم لدى محفظة جيب. رقم العملية: ${randomRef}. المرسل: العميل الجديد. التاريخ: 2026/08/07`;
    } else if (chosenSender === 'kuraimi') {
      txt = `إيداع تحويل بمبلغ ${randomAmt.toLocaleString()} YER. مرجع العملية ${randomRef}. العميل: شركة الأمان. وقت: 07-08-2026`;
    } else {
      txt = `استلمت مبلغ ${randomAmt.toLocaleString()} YER بنجاح. رقم الحوالة: ${randomRef}. من: محلات الفجر. 07/08/2026`;
    }

    setSelectedSender(chosenSender);
    setSmsText(txt);
    setPreviewParsed(parseSmsText(txt, chosenSender));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!smsText.trim()) return;
    onAddTransaction(smsText, selectedSender);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-xs">
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl w-full max-w-2xl shadow-2xl overflow-hidden animate-in fade-in zoom-in-95 duration-200">
        
        {/* Modal Header */}
        <div className="bg-slate-900 text-white px-6 py-4 flex items-center justify-between border-b border-slate-800">
          <div className="flex items-center gap-2.5">
            <div className="p-2 bg-emerald-500/20 text-emerald-400 rounded-lg">
              <Smartphone className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-bold text-base">محاكاة استقبال إشعار رسالة SMS جديدة</h3>
              <p className="text-xs text-slate-400">تصل الرسائل إلى جوال المحفظة دون تحديد الفرع</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg hover:bg-slate-800 text-slate-400 hover:text-white transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body */}
        <form onSubmit={handleSubmit} className="p-6 space-y-5">
          
          {/* Quick Preset Templates */}
          <div>
            <div className="flex items-center justify-between mb-2">
              <label className="text-xs font-bold text-slate-700 dark:text-slate-300">
                اختر نموذج رسالة جاهزة (أو اكتب نصاً حراً):
              </label>
              <button
                type="button"
                onClick={handleGenerateRandom}
                className="text-xs text-emerald-600 dark:text-emerald-400 hover:underline flex items-center gap-1 font-medium"
              >
                <RefreshCw className="w-3 h-3" />
                توليد رسالة عشوائية
              </button>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
              {SMS_TEMPLATES.map((tmpl) => (
                <button
                  key={tmpl.senderId}
                  type="button"
                  onClick={() => handleTemplateSelect(tmpl)}
                  className={`p-2.5 rounded-xl border text-right transition-all text-xs ${
                    selectedSender === tmpl.senderId && smsText === tmpl.text
                      ? 'bg-emerald-500/10 border-emerald-500 text-emerald-700 dark:text-emerald-300 font-bold'
                      : 'bg-slate-50 dark:bg-slate-800 border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300 hover:border-slate-300'
                  }`}
                >
                  <span className="block font-bold">{tmpl.providerName}</span>
                  <span className="block text-[10px] text-slate-500 dark:text-slate-400 mt-0.5 truncate font-mono">
                    {tmpl.senderId}
                  </span>
                </button>
              ))}
            </div>
          </div>

          {/* Sender Name Configuration */}
          <div>
            <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
              اسم مرسل الرسالة (Sender ID):
            </label>
            <input
              type="text"
              value={selectedSender}
              onChange={(e) => handleSenderChange(e.target.value)}
              placeholder="مثال: jaib, Kuraimi, Jawali..."
              className="w-full px-3 py-2 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg focus:ring-2 focus:ring-emerald-500 text-slate-800 dark:text-slate-100 font-mono"
            />
          </div>

          {/* SMS Body TextArea */}
          <div>
            <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
              نص الرسالة النصية الواردة:
            </label>
            <textarea
              rows={3}
              value={smsText}
              onChange={(e) => handleTextChange(e.target.value)}
              placeholder="أدخل نص الرسالة كما تصلك على الجوال..."
              className="w-full p-3 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl focus:ring-2 focus:ring-emerald-500 text-slate-800 dark:text-slate-100 font-mono leading-relaxed"
            />
          </div>

          {/* Instant Parsed Preview Card */}
          <div className="bg-emerald-50/50 dark:bg-emerald-950/20 p-3.5 rounded-xl border border-emerald-500/30 text-xs space-y-2">
            <span className="font-bold text-emerald-800 dark:text-emerald-300 flex items-center gap-1">
              <Sparkles className="w-3.5 h-3.5" /> نتيجة التحليل التلقائي المستخرجة:
            </span>
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 text-[11px]">
              <div>
                <span className="text-slate-500 dark:text-slate-400 block">المبلغ:</span>
                <strong className="text-emerald-600 dark:text-emerald-400 text-sm font-bold">
                  {previewParsed.amount.toLocaleString()} {previewParsed.currency}
                </strong>
              </div>
              <div>
                <span className="text-slate-500 dark:text-slate-400 block">رقم العملية / المرجع:</span>
                <strong className="font-mono text-slate-800 dark:text-slate-200">
                  {previewParsed.transferRefNumber}
                </strong>
              </div>
              <div>
                <span className="text-slate-500 dark:text-slate-400 block">اسم المحول:</span>
                <strong className="text-slate-800 dark:text-slate-200">
                  {previewParsed.senderCustomerName || 'غير محدد'}
                </strong>
              </div>
            </div>
          </div>

          {/* Form Action Buttons */}
          <div className="flex items-center justify-end gap-3 pt-2">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-xs font-medium text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg"
            >
              إلغاء
            </button>
            <button
              type="submit"
              className="flex items-center gap-2 px-5 py-2.5 bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold rounded-xl shadow-md transition-all active:scale-95"
            >
              <Send className="w-4 h-4" />
              <span>إدخال وتمرير الإشعار لصندوق المعلقة</span>
            </button>
          </div>

        </form>
      </div>
    </div>
  );
};
