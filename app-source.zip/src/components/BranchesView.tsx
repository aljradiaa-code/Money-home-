import React, { useState } from 'react';
import {
  Building2,
  Plus,
  MapPin,
  User,
  Phone,
  Target,
  FileText,
  Edit2,
  TrendingUp,
  X,
  CheckCircle2,
  Printer,
  Calendar,
} from 'lucide-react';
import { Branch, SMSTransaction } from '../types';
import { formatCurrency } from '../utils/smsParser';

interface BranchesViewProps {
  branches: Branch[];
  transactions: SMSTransaction[];
  onAddBranch: (branchData: Omit<Branch, 'id' | 'totalToday' | 'totalAllTime' | 'transactionCountToday'>) => void;
  onEditBranch: (branch: Branch) => void;
  onPrintBranchLedger: (branch: Branch, branchTxs: SMSTransaction[]) => void;
}

export const BranchesView: React.FC<BranchesViewProps> = ({
  branches,
  transactions,
  onAddBranch,
  onEditBranch,
  onPrintBranchLedger,
}) => {
  const [selectedBranch, setSelectedBranch] = useState<Branch | null>(null);
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [editingBranch, setEditingBranch] = useState<Branch | null>(null);

  // Form State for Add/Edit
  const [name, setName] = useState('');
  const [code, setCode] = useState('');
  const [city, setCity] = useState('');
  const [address, setAddress] = useState('');
  const [managerName, setManagerName] = useState('');
  const [phone, setPhone] = useState('');
  const [dailyTarget, setDailyTarget] = useState<string>('300000');
  const [color, setColor] = useState('emerald');

  const openAddModal = () => {
    setName('');
    setCode(`BR-${branches.length + 1}`);
    setCity('صنعاء');
    setAddress('');
    setManagerName('');
    setPhone('');
    setDailyTarget('300000');
    setColor('emerald');
    setEditingBranch(null);
    setIsAddModalOpen(true);
  };

  const openEditModal = (b: Branch) => {
    setEditingBranch(b);
    setName(b.name);
    setCode(b.code);
    setCity(b.city);
    setAddress(b.address || '');
    setManagerName(b.managerName || '');
    setPhone(b.phone || '');
    setDailyTarget(b.dailyTarget?.toString() || '300000');
    setColor(b.color || 'emerald');
    setIsAddModalOpen(true);
  };

  const handleSaveForm = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) return;

    if (editingBranch) {
      onEditBranch({
        ...editingBranch,
        name,
        code,
        city,
        address,
        managerName,
        phone,
        dailyTarget: parseFloat(dailyTarget) || 300000,
        color,
      });
    } else {
      onAddBranch({
        name,
        code,
        city,
        address,
        managerName,
        phone,
        dailyTarget: parseFloat(dailyTarget) || 300000,
        color,
      });
    }

    setIsAddModalOpen(false);
  };

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="bg-white dark:bg-slate-900 p-5 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="flex items-start gap-3.5">
          <div className="p-3 bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 rounded-xl border border-emerald-500/20 shrink-0">
            <Building2 className="w-6 h-6" />
          </div>
          <div>
            <h2 className="text-lg font-bold text-slate-900 dark:text-white">
              إدارة فروع المحلات ودواتر الأستاذ ({branches.length} فروع)
            </h2>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
              متابعة مستمرة لإجمالي التحويلات المقيدة لكل فرع، الأهداف اليومية، وسجلات العمليات التفصيلية.
            </p>
          </div>
        </div>

        <button
          onClick={openAddModal}
          className="shrink-0 flex items-center justify-center gap-2 px-4 py-2.5 bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs rounded-xl shadow-md transition-all active:scale-95"
        >
          <Plus className="w-4 h-4" />
          <span>إضافة فرع جديد للمحلات</span>
        </button>
      </div>

      {/* Branch Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
        {branches.map((branch) => {
          const branchTxs = transactions.filter((t) => t.branchId === branch.id);
          const totalToday = branchTxs.reduce((sum, t) => sum + t.amount, 0);
          const target = branch.dailyTarget || 300000;
          const targetPercent = Math.min(Math.round((totalToday / target) * 100), 100);

          return (
            <div
              key={branch.id}
              className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm hover:shadow-md transition-all duration-200 overflow-hidden flex flex-col justify-between"
            >
              <div className="p-5 space-y-4">
                
                {/* Branch Header */}
                <div className="flex items-start justify-between gap-2 pb-3 border-b border-slate-100 dark:border-slate-800">
                  <div className="flex items-center gap-2.5">
                    <div className="w-10 h-10 rounded-xl bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 font-bold flex items-center justify-center text-xs border border-emerald-500/20">
                      {branch.code}
                    </div>
                    <div>
                      <h3 className="font-bold text-sm text-slate-900 dark:text-white">
                        {branch.name}
                      </h3>
                      <span className="text-[11px] text-slate-500 dark:text-slate-400 flex items-center gap-1 mt-0.5">
                        <MapPin className="w-3 h-3 text-slate-400" />
                        {branch.city} {branch.address ? `- ${branch.address}` : ''}
                      </span>
                    </div>
                  </div>

                  <button
                    onClick={() => openEditModal(branch)}
                    className="p-1.5 rounded-lg text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
                    title="تعديل تفاصيل الفرع"
                  >
                    <Edit2 className="w-4 h-4" />
                  </button>
                </div>

                {/* Manager & Contact */}
                <div className="grid grid-cols-2 gap-2 text-xs bg-slate-50 dark:bg-slate-800/50 p-2.5 rounded-xl">
                  <div>
                    <span className="text-slate-400 block text-[10px] flex items-center gap-1">
                      <User className="w-3 h-3 text-slate-400" /> المسؤول
                    </span>
                    <strong className="text-slate-700 dark:text-slate-200">
                      {branch.managerName || 'غير محدد'}
                    </strong>
                  </div>

                  <div>
                    <span className="text-slate-400 block text-[10px] flex items-center gap-1">
                      <Phone className="w-3 h-3 text-slate-400" /> الهاتف
                    </span>
                    <strong className="font-mono text-slate-700 dark:text-slate-200">
                      {branch.phone || 'غير محدد'}
                    </strong>
                  </div>
                </div>

                {/* Financial Summary */}
                <div className="space-y-2">
                  <div className="flex items-center justify-between text-xs">
                    <span className="text-slate-500 dark:text-slate-400 font-medium">مبيعات/تحويلات اليوم:</span>
                    <strong className="text-base font-black text-emerald-600 dark:text-emerald-400">
                      {formatCurrency(totalToday)}
                    </strong>
                  </div>

                  {/* Daily Target Bar */}
                  <div className="space-y-1">
                    <div className="flex items-center justify-between text-[11px] text-slate-400">
                      <span className="flex items-center gap-1">
                        <Target className="w-3 h-3 text-emerald-500" />
                        الهدف اليومي ({formatCurrency(target)})
                      </span>
                      <span className="font-bold text-slate-700 dark:text-slate-300">
                        {targetPercent}%
                      </span>
                    </div>
                    <div className="w-full bg-slate-100 dark:bg-slate-800 h-2 rounded-full overflow-hidden">
                      <div
                        className="bg-gradient-to-r from-emerald-500 to-teal-400 h-full rounded-full transition-all duration-500"
                        style={{ width: `${targetPercent}%` }}
                      ></div>
                    </div>
                  </div>

                  <div className="flex items-center justify-between text-[11px] text-slate-500 dark:text-slate-400 pt-1">
                    <span>عدد الحوالات اليوم: <strong>{branchTxs.length} عملية</strong></span>
                    <span>التراكمي العام: <strong>{formatCurrency(branch.totalAllTime + totalToday)}</strong></span>
                  </div>
                </div>

              </div>

              {/* Card Footer Actions */}
              <div className="bg-slate-50 dark:bg-slate-900/80 px-5 py-3 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between">
                <button
                  onClick={() => setSelectedBranch(branch)}
                  className="flex items-center gap-1.5 text-xs font-bold text-emerald-600 dark:text-emerald-400 hover:underline"
                >
                  <FileText className="w-4 h-4" />
                  <span>عرض دفتر أستاذ الفرع ({branchTxs.length})</span>
                </button>

                <button
                  onClick={() => onPrintBranchLedger(branch, branchTxs)}
                  className="p-1.5 text-slate-500 hover:text-slate-900 dark:hover:text-white rounded-lg hover:bg-slate-200 dark:hover:bg-slate-800"
                  title="طباعة تقرير الفرع"
                >
                  <Printer className="w-4 h-4" />
                </button>
              </div>

            </div>
          );
        })}
      </div>

      {/* Branch Ledger Modal */}
      {selectedBranch && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-xs">
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl w-full max-w-4xl shadow-2xl overflow-hidden max-h-[90vh] flex flex-col">
            
            {/* Header */}
            <div className="bg-slate-900 text-white px-6 py-4 flex items-center justify-between border-b border-slate-800 shrink-0">
              <div className="flex items-center gap-2.5">
                <div className="p-2 bg-emerald-500/20 text-emerald-400 rounded-lg">
                  <FileText className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-bold text-base">
                    دفتر أستاذ الفرع: {selectedBranch.name} ({selectedBranch.city})
                  </h3>
                  <p className="text-xs text-slate-400">سجل كافة الحوالات والمبالغ المقيدة لحساب هذا الفرع</p>
                </div>
              </div>

              <div className="flex items-center gap-2">
                <button
                  onClick={() =>
                    onPrintBranchLedger(
                      selectedBranch,
                      transactions.filter((t) => t.branchId === selectedBranch.id)
                    )
                  }
                  className="flex items-center gap-1.5 px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-white text-xs font-semibold rounded-lg border border-slate-700"
                >
                  <Printer className="w-4 h-4 text-emerald-400" />
                  <span>طباعة كشف الحساب</span>
                </button>
                <button onClick={() => setSelectedBranch(null)} className="p-1.5 text-slate-400 hover:text-white">
                  <X className="w-5 h-5" />
                </button>
              </div>
            </div>

            {/* Content Table */}
            <div className="p-6 overflow-y-auto space-y-4 flex-1">
              {(() => {
                const branchTxs = transactions.filter((t) => t.branchId === selectedBranch.id);
                const totalBranchToday = branchTxs.reduce((sum, t) => sum + t.amount, 0);

                if (branchTxs.length === 0) {
                  return (
                    <div className="p-12 text-center text-slate-500">
                      لا توجد أي حوالات مقيدة لهذا الفرع بعد اليوم.
                    </div>
                  );
                }

                return (
                  <div className="space-y-4">
                    <div className="bg-emerald-50 dark:bg-emerald-950/20 p-4 rounded-xl border border-emerald-500/20 flex items-center justify-between">
                      <span className="text-xs font-bold text-slate-700 dark:text-slate-300">
                        إجمالي التحويلات المقيدة اليوم:
                      </span>
                      <strong className="text-lg font-black text-emerald-600 dark:text-emerald-400">
                        {formatCurrency(totalBranchToday)} ({branchTxs.length} حوالة)
                      </strong>
                    </div>

                    <div className="border border-slate-200 dark:border-slate-800 rounded-xl overflow-hidden">
                      <table className="w-full text-xs text-right">
                        <thead className="bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 font-bold">
                          <tr>
                            <th className="p-3">#</th>
                            <th className="p-3">رقم العملية</th>
                            <th className="p-3">المحفظة</th>
                            <th className="p-3">المبلغ</th>
                            <th className="p-3">اسم المحول</th>
                            <th className="p-3">الوقت</th>
                            <th className="p-3">الملاحظات</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                          {branchTxs.map((tx, idx) => (
                            <tr key={tx.id} className="hover:bg-slate-50 dark:hover:bg-slate-800/50">
                              <td className="p-3 font-bold">{idx + 1}</td>
                              <td className="p-3 font-mono font-bold text-slate-900 dark:text-white">
                                {tx.transferRefNumber}
                              </td>
                              <td className="p-3">
                                <span className="bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 px-2 py-0.5 rounded font-medium">
                                  {tx.providerName}
                                </span>
                              </td>
                              <td className="p-3 font-black text-emerald-600 dark:text-emerald-400">
                                {formatCurrency(tx.amount, tx.currency)}
                              </td>
                              <td className="p-3">{tx.senderCustomerName || 'عام'}</td>
                              <td className="p-3 font-mono text-slate-500">{tx.formattedTime}</td>
                              <td className="p-3 text-slate-500">{tx.notes || '-'}</td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  </div>
                );
              })()}
            </div>

          </div>
        </div>
      )}

      {/* Add/Edit Branch Modal */}
      {isAddModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-xs">
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl w-full max-w-lg shadow-2xl overflow-hidden">
            <div className="bg-slate-900 text-white px-6 py-4 flex items-center justify-between border-b border-slate-800">
              <h3 className="font-bold text-base">
                {editingBranch ? 'تعديل بيانات الفرع' : 'إضافة فرع جديد للمحلات'}
              </h3>
              <button onClick={() => setIsAddModalOpen(false)} className="p-1.5 text-slate-400 hover:text-white">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveForm} className="p-6 space-y-4 text-xs">
              <div>
                <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">
                  اسم الفرع الرئيسي/الفرعي:
                </label>
                <input
                  type="text"
                  required
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="مثال: فرع شارع الستين - صنعاء"
                  className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg text-slate-800 dark:text-slate-100"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">رمز الفرع:</label>
                  <input
                    type="text"
                    required
                    value={code}
                    onChange={(e) => setCode(e.target.value)}
                    placeholder="SNA-01"
                    className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg font-mono text-slate-800 dark:text-slate-100"
                  />
                </div>

                <div>
                  <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">المدينة:</label>
                  <input
                    type="text"
                    required
                    value={city}
                    onChange={(e) => setCity(e.target.value)}
                    placeholder="صنعاء / عدن / تعز..."
                    className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg text-slate-800 dark:text-slate-100"
                  />
                </div>
              </div>

              <div>
                <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">اسم المسؤول عن الفرع:</label>
                <input
                  type="text"
                  value={managerName}
                  onChange={(e) => setManagerName(e.target.value)}
                  placeholder="أحمد علي"
                  className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg text-slate-800 dark:text-slate-100"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">هاتف الفرع:</label>
                  <input
                    type="text"
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    placeholder="771234567"
                    className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg font-mono text-slate-800 dark:text-slate-100"
                  />
                </div>

                <div>
                  <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">الهدف اليومي (بالريال):</label>
                  <input
                    type="number"
                    value={dailyTarget}
                    onChange={(e) => setDailyTarget(e.target.value)}
                    placeholder="300000"
                    className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg font-mono text-slate-800 dark:text-slate-100"
                  />
                </div>
              </div>

              <div className="pt-3 flex items-center justify-end gap-2 border-t border-slate-100 dark:border-slate-800">
                <button
                  type="button"
                  onClick={() => setIsAddModalOpen(false)}
                  className="px-4 py-2 text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg"
                >
                  إلغاء
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-emerald-600 hover:bg-emerald-500 text-white font-bold rounded-xl shadow-md"
                >
                  حفظ الفرع
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
