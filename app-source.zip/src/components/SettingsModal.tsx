import React, { useState } from 'react';
import { Settings, Plus, Trash2, Smartphone, Check, RefreshCw, Download } from 'lucide-react';
import { WalletProviderRule } from '../types';

interface SettingsModalProps {
  providers: WalletProviderRule[];
  onAddProvider: (p: WalletProviderRule) => void;
  onDeleteProvider: (id: string) => void;
  onResetData: () => void;
}

export const SettingsModal: React.FC<SettingsModalProps> = ({
  providers,
  onAddProvider,
  onDeleteProvider,
  onResetData,
}) => {
  const [name, setName] = useState('');
  const [senderId, setSenderId] = useState('');
  const [logoText, setLogoText] = useState('');

  const handleAdd = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim() || !senderId.trim()) return;

    onAddProvider({
      id: senderId.toLowerCase().trim(),
      name,
      senderId: senderId.toLowerCase().trim(),
      color: 'emerald',
      logoText: logoText || name,
      active: true,
    });

    setName('');
    setSenderId('');
    setLogoText('');
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-white dark:bg-slate-900 p-5 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="p-3 bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 rounded-xl">
            <Settings className="w-6 h-6" />
          </div>
          <div>
            <h2 className="text-lg font-bold text-slate-900 dark:text-white">
              إعدادات مرسلي الرسائل وقواعد المحافظ
            </h2>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
              إدارة أسماء مرسلي الرسائل النصية (Sender IDs) التي يتم التعرف عليها تلقائياً.
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={onResetData}
            className="flex items-center gap-1.5 px-3 py-2 bg-rose-50 dark:bg-rose-950/30 text-rose-600 dark:text-rose-400 border border-rose-200 dark:border-rose-900 rounded-xl text-xs font-bold hover:bg-rose-100"
          >
            <RefreshCw className="w-3.5 h-3.5" />
            <span>استعادة البيانات الافتراضية</span>
          </button>
        </div>
      </div>

      {/* Add New Provider Rule Form */}
      <div className="bg-white dark:bg-slate-900 p-5 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm space-y-4">
        <h3 className="font-bold text-sm text-slate-900 dark:text-white flex items-center gap-2">
          <Smartphone className="w-4 h-4 text-emerald-500" />
          إضافة اسم مرسل جديد (مثال: jaib أو Kuraimi):
        </h3>

        <form onSubmit={handleAdd} className="grid grid-cols-1 sm:grid-cols-4 gap-3 text-xs">
          <div>
            <label className="block text-slate-500 mb-1 font-semibold">اسم المحفظة/البنك:</label>
            <input
              type="text"
              required
              placeholder="مثال: محفظة جيب"
              value={name}
              onChange={(e) => setName(e.target.value)}
              className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg"
            />
          </div>

          <div>
            <label className="block text-slate-500 mb-1 font-semibold">اسم المرسل (Sender ID):</label>
            <input
              type="text"
              required
              placeholder="jaib"
              value={senderId}
              onChange={(e) => setSenderId(e.target.value)}
              className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg font-mono"
            />
          </div>

          <div>
            <label className="block text-slate-500 mb-1 font-semibold">الشعار المختصر:</label>
            <input
              type="text"
              placeholder="جيب"
              value={logoText}
              onChange={(e) => setLogoText(e.target.value)}
              className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg"
            />
          </div>

          <div className="flex items-end">
            <button
              type="submit"
              className="w-full py-2 bg-emerald-600 hover:bg-emerald-500 text-white font-bold rounded-lg transition-all flex items-center justify-center gap-1.5"
            >
              <Plus className="w-4 h-4" />
              <span>إضافة اسم المرسل</span>
            </button>
          </div>
        </form>
      </div>

      {/* Existing Wallet Providers Table */}
      <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm overflow-hidden">
        <table className="w-full text-xs text-right">
          <thead className="bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 font-bold">
            <tr>
              <th className="p-3">اسم المحفظة والخدمة</th>
              <th className="p-3">اسم مرسل الرسالة النصية (Sender ID)</th>
              <th className="p-3">الشعار المختصر</th>
              <th className="p-3">الحالة</th>
              <th className="p-3 text-center">إجراء</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
            {providers.map((p) => (
              <tr key={p.id} className="hover:bg-slate-50 dark:hover:bg-slate-800/50">
                <td className="p-3 font-bold text-slate-900 dark:text-white">{p.name}</td>
                <td className="p-3 font-mono font-bold text-emerald-600 dark:text-emerald-400">
                  {p.senderId}
                </td>
                <td className="p-3 font-bold">{p.logoText}</td>
                <td className="p-3">
                  <span className="bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 px-2 py-0.5 rounded font-bold">
                    نشط ومفعل
                  </span>
                </td>
                <td className="p-3 text-center">
                  <button
                    onClick={() => onDeleteProvider(p.id)}
                    className="p-1.5 text-slate-400 hover:text-rose-600 rounded-lg hover:bg-rose-50 dark:hover:bg-rose-950/30"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};
