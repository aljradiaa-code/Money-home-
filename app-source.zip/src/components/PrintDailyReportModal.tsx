import React from 'react';
import { X, Printer, Wallet, Building2, ShieldCheck } from 'lucide-react';
import { Branch, SMSTransaction } from '../types';
import { formatCurrency } from '../utils/smsParser';

interface PrintDailyReportModalProps {
  isOpen: boolean;
  onClose: () => void;
  transactions: SMSTransaction[];
  branches: Branch[];
}

export const PrintDailyReportModal: React.FC<PrintDailyReportModalProps> = ({
  isOpen,
  onClose,
  transactions,
  branches,
}) => {
  if (!isOpen) return null;

  const todayStr = new Date().toLocaleDateString('ar-YE', {
    weekday: 'long',
    year: 'numeric',
    month: 'long',
    day: 'numeric',
  });

  const totalAmount = transactions.reduce((sum, t) => sum + t.amount, 0);
  const assignedTxs = transactions.filter((t) => t.status === 'ASSIGNED');
  const unassignedTxs = transactions.filter((t) => t.status === 'UNASSIGNED');

  const totalAssigned = assignedTxs.reduce((sum, t) => sum + t.amount, 0);
  const totalUnassigned = unassignedTxs.reduce((sum, t) => sum + t.amount, 0);

  const handleTriggerPrint = () => {
    window.print();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-xs overflow-y-auto print:p-0 print:bg-white print:static">
      <div className="bg-white text-slate-900 rounded-2xl w-full max-w-3xl shadow-2xl border border-slate-200 overflow-hidden print:border-none print:shadow-none print:w-full">
        
        {/* Top Control Bar (Hidden when printing) */}
        <div className="bg-slate-900 text-white px-6 py-4 flex items-center justify-between print:hidden">
          <div className="flex items-center gap-2">
            <Printer className="w-5 h-5 text-emerald-400" />
            <span className="font-bold text-sm">معاينة كشف الإغلاق والمطابقة اليومية للطباعة</span>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={handleTriggerPrint}
              className="flex items-center gap-1.5 px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs rounded-xl shadow transition-all"
            >
              <Printer className="w-4 h-4" />
              <span>طباعة الآن</span>
            </button>
            <button onClick={onClose} className="p-1.5 text-slate-400 hover:text-white">
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Printable Document Body */}
        <div className="p-8 space-y-6 text-right dir-rtl font-sans bg-white text-slate-900">
          
          {/* Document Header */}
          <div className="flex items-center justify-between border-b-2 border-slate-900 pb-5">
            <div>
              <h1 className="text-2xl font-black text-slate-900 tracking-tight">
                تقرير المطابقة والإغلاق اليومي لمحفظة الفروع
              </h1>
              <p className="text-xs text-slate-600 mt-1">
                تاريخ الكشف: <strong>{todayStr}</strong>
              </p>
            </div>
            <div className="text-left">
              <div className="inline-block p-2 bg-slate-100 rounded-xl font-bold text-xs text-slate-800">
                المحاسب الذكي للفروع
              </div>
            </div>
          </div>

          {/* Portfolio Summary Card */}
          <div className="grid grid-cols-3 gap-3 text-xs bg-slate-50 p-4 rounded-xl border border-slate-200">
            <div>
              <span className="text-slate-500 block">إجمالي وارد المحفظة:</span>
              <strong className="text-lg font-black text-slate-900">
                {formatCurrency(totalAmount)}
              </strong>
            </div>

            <div>
              <span className="text-slate-500 block">إجمالي المقيد للفروع:</span>
              <strong className="text-lg font-black text-emerald-700">
                {formatCurrency(totalAssigned)}
              </strong>
            </div>

            <div>
              <span className="text-slate-500 block">غير المقيد (المعلق):</span>
              <strong className={`text-lg font-black ${totalUnassigned > 0 ? 'text-amber-600' : 'text-emerald-700'}`}>
                {formatCurrency(totalUnassigned)}
              </strong>
            </div>
          </div>

          {/* Branch Distribution Table */}
          <div className="space-y-2">
            <h3 className="font-bold text-sm text-slate-900">أولاً: بيان توزيع مبالغ التحويلات على الفروع:</h3>
            <table className="w-full text-xs text-right border-collapse">
              <thead>
                <tr className="bg-slate-900 text-white font-bold">
                  <th className="p-2.5 border border-slate-800">الفرع</th>
                  <th className="p-2.5 border border-slate-800">المدينة</th>
                  <th className="p-2.5 border border-slate-800">عدد الحوالات</th>
                  <th className="p-2.5 border border-slate-800">إجمالي المبلغ</th>
                  <th className="p-2.5 border border-slate-800">النسبة</th>
                </tr>
              </thead>
              <tbody>
                {branches.map((b) => {
                  const branchTxs = transactions.filter((t) => t.branchId === b.id);
                  const bSum = branchTxs.reduce((sum, t) => sum + t.amount, 0);
                  const pct = totalAmount > 0 ? Math.round((bSum / totalAmount) * 100) : 0;

                  return (
                    <tr key={b.id} className="border-b border-slate-200">
                      <td className="p-2.5 font-bold border border-slate-200">{b.name}</td>
                      <td className="p-2.5 border border-slate-200">{b.city}</td>
                      <td className="p-2.5 font-mono border border-slate-200">{branchTxs.length}</td>
                      <td className="p-2.5 font-black text-emerald-800 border border-slate-200">
                        {formatCurrency(bSum)}
                      </td>
                      <td className="p-2.5 font-bold border border-slate-200">{pct}%</td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>

          {/* Detailed Transaction List */}
          <div className="space-y-2 pt-2">
            <h3 className="font-bold text-sm text-slate-900">ثانياً: سجل الحوالات المقيدة بالتفصيل:</h3>
            <table className="w-full text-[11px] text-right border-collapse">
              <thead>
                <tr className="bg-slate-100 text-slate-800 font-bold border-b border-slate-300">
                  <th className="p-2">#</th>
                  <th className="p-2">رقم العملية</th>
                  <th className="p-2">المحفظة</th>
                  <th className="p-2">المبلغ</th>
                  <th className="p-2">المحول</th>
                  <th className="p-2">الفرع المقيد له</th>
                  <th className="p-2">الوقت</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200">
                {assignedTxs.map((tx, idx) => (
                  <tr key={tx.id}>
                    <td className="p-2 font-bold">{idx + 1}</td>
                    <td className="p-2 font-mono font-bold">{tx.transferRefNumber}</td>
                    <td className="p-2">{tx.providerName}</td>
                    <td className="p-2 font-black text-slate-900">{formatCurrency(tx.amount, tx.currency)}</td>
                    <td className="p-2">{tx.senderCustomerName || 'عام'}</td>
                    <td className="p-2 font-bold">{tx.branchName}</td>
                    <td className="p-2 font-mono text-slate-500">{tx.formattedTime}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {/* Signature Block */}
          <div className="grid grid-cols-2 gap-8 pt-8 mt-8 border-t border-slate-300 text-xs text-center">
            <div>
              <p className="font-bold text-slate-700">مسؤول إدارة المحافظ المالية</p>
              <div className="h-12 border-b border-dashed border-slate-400 mt-2"></div>
              <p className="text-[10px] text-slate-400 mt-1">التوقيع والختم</p>
            </div>

            <div>
              <p className="font-bold text-slate-700">المراجع المحاسبي العام</p>
              <div className="h-12 border-b border-dashed border-slate-400 mt-2"></div>
              <p className="text-[10px] text-slate-400 mt-1">التوقيع والاعتماد</p>
            </div>
          </div>

        </div>

      </div>
    </div>
  );
};
