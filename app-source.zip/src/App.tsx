import React, { useState, useEffect } from 'react';
import {
  INITIAL_BRANCHES,
  INITIAL_TRANSACTIONS,
} from './data/initialData';
import {
  Branch,
  SMSTransaction,
  WalletProviderRule,
  DailyCloseout,
} from './types';
import { parseSmsText, DEFAULT_WALLET_PROVIDERS, formatCurrency } from './utils/smsParser';
import { Navbar } from './components/Navbar';
import { UnassignedFeed } from './components/UnassignedFeed';
import { SimulateSmsModal } from './components/SimulateSmsModal';
import { PasteSmsModal } from './components/PasteSmsModal';
import { ScanSmsModal } from './components/ScanSmsModal';
import { BranchesView } from './components/BranchesView';
import { TransactionsTable } from './components/TransactionsTable';
import { ReconciliationView } from './components/ReconciliationView';
import { AnalyticsView } from './components/AnalyticsView';
import { SettingsModal } from './components/SettingsModal';
import { PrintDailyReportModal } from './components/PrintDailyReportModal';
import {
  Bell,
  Building2,
  CheckCircle2,
  Sparkles,
  ArrowRightLeft,
  Clock,
  PlusCircle,
  FileText,
  Camera,
  RotateCcw,
  Layers,
} from 'lucide-react';

export default function App() {
  // State Initialization with localStorage persistence
  const [branches, setBranches] = useState<Branch[]>(() => {
    const saved = localStorage.getItem('store_wallet_branches');
    return saved ? JSON.parse(saved) : INITIAL_BRANCHES;
  });

  const [transactions, setTransactions] = useState<SMSTransaction[]>(() => {
    const saved = localStorage.getItem('store_wallet_transactions');
    return saved ? JSON.parse(saved) : INITIAL_TRANSACTIONS;
  });

  const [providers, setProviders] = useState<WalletProviderRule[]>(() => {
    const saved = localStorage.getItem('store_wallet_providers');
    return saved ? JSON.parse(saved) : DEFAULT_WALLET_PROVIDERS;
  });

  const [closeouts, setCloseouts] = useState<DailyCloseout[]>(() => {
    const saved = localStorage.getItem('store_wallet_closeouts');
    return saved ? JSON.parse(saved) : [];
  });

  const [activeTab, setActiveTab] = useState('dashboard');

  // Modal States
  const [isSimulateModalOpen, setIsSimulateModalOpen] = useState(false);
  const [isPasteModalOpen, setIsPasteModalOpen] = useState(false);
  const [isScanModalOpen, setIsScanModalOpen] = useState(false);
  const [isPrintModalOpen, setIsPrintModalOpen] = useState(false);

  // Toast Notification State
  const [toast, setToast] = useState<{
    message: string;
    type?: 'success' | 'info';
    undoTxId?: string;
    previousBranchId?: string;
  } | null>(null);

  // Sync to localStorage
  useEffect(() => {
    localStorage.setItem('store_wallet_branches', JSON.stringify(branches));
  }, [branches]);

  useEffect(() => {
    localStorage.setItem('store_wallet_transactions', JSON.stringify(transactions));
  }, [transactions]);

  useEffect(() => {
    localStorage.setItem('store_wallet_providers', JSON.stringify(providers));
  }, [providers]);

  useEffect(() => {
    localStorage.setItem('store_wallet_closeouts', JSON.stringify(closeouts));
  }, [closeouts]);

  // Recalculate branch totals dynamically
  useEffect(() => {
    setBranches((prevBranches) =>
      prevBranches.map((b) => {
        const branchTxs = transactions.filter(
          (t) => t.branchId === b.id && t.status === 'ASSIGNED'
        );
        const totalToday = branchTxs.reduce((sum, t) => sum + t.amount, 0);
        return {
          ...b,
          totalToday,
          transactionCountToday: branchTxs.length,
        };
      })
    );
  }, [transactions]);

  const showToast = (
    message: string,
    type: 'success' | 'info' = 'success',
    undoTxId?: string,
    previousBranchId?: string
  ) => {
    setToast({ message, type, undoTxId, previousBranchId });
    setTimeout(() => {
      setToast(null);
    }, 5000);
  };

  // 1. Assign transaction to branch
  const handleAssignBranch = (transactionId: string, branchId: string, notes?: string) => {
    const txIndex = transactions.findIndex((t) => t.id === transactionId);
    if (txIndex === -1) return;

    const oldTx = transactions[txIndex];
    const previousBranchId = oldTx.branchId;

    const branchObj = branches.find((b) => b.id === branchId);
    const branchName = branchObj ? branchObj.name : undefined;

    const updatedTx: SMSTransaction = {
      ...oldTx,
      status: branchId ? 'ASSIGNED' : 'UNASSIGNED',
      branchId: branchId || undefined,
      branchName,
      assignedAt: branchId ? new Date().toISOString() : undefined,
      notes: notes !== undefined ? notes : oldTx.notes,
    };

    const newTxs = [...transactions];
    newTxs[txIndex] = updatedTx;
    setTransactions(newTxs);

    if (branchId && branchObj) {
      showToast(
        `تم تقييد الحوالة رقم #${oldTx.transferRefNumber} بمبلغ ${formatCurrency(oldTx.amount)} لفرع ${branchObj.name} بنجاح!`,
        'success',
        transactionId,
        previousBranchId
      );
    } else {
      showToast(`تم تحويل الحوالة رقم #${oldTx.transferRefNumber} إلى القائمة المعلقة`, 'info');
    }
  };

  // 2. Undo last assignment
  const handleUndoAssignment = () => {
    if (!toast || !toast.undoTxId) return;

    const { undoTxId, previousBranchId } = toast;
    handleAssignBranch(undoTxId, previousBranchId || '');
    setToast(null);
  };

  // 3. Bulk Assign
  const handleBulkAssignBranch = (transactionIds: string[], branchId: string) => {
    const branchObj = branches.find((b) => b.id === branchId);
    if (!branchObj) return;

    setTransactions((prev) =>
      prev.map((t) => {
        if (transactionIds.includes(t.id)) {
          return {
            ...t,
            status: 'ASSIGNED',
            branchId,
            branchName: branchObj.name,
            assignedAt: new Date().toISOString(),
          };
        }
        return t;
      })
    );

    showToast(`تم تقييد ${transactionIds.length} حوالة جماعياً لفرع ${branchObj.name} بنجاح!`);
  };

  // 4. Add single SMS Transaction
  const handleAddTransaction = (
    rawSms: string,
    senderId: string,
    branchId?: string,
    overrideParsed?: any
  ) => {
    const parsed = overrideParsed || parseSmsText(rawSms, senderId);
    const dateObj = new Date();

    const branchObj = branches.find((b) => b.id === branchId);

    const newTx: SMSTransaction = {
      id: 'tx-' + Date.now(),
      rawSmsText: rawSms,
      senderId,
      providerName: parsed.providerName || 'محفظة جيب',
      transferRefNumber: parsed.transferRefNumber || 'TXN-' + Math.floor(Math.random() * 1000000),
      amount: parsed.amount || 0,
      currency: parsed.currency || 'YER',
      senderCustomerName: parsed.senderCustomerName,
      customerPhone: parsed.customerPhone,
      timestamp: dateObj.toISOString(),
      formattedDate: dateObj.toLocaleDateString('ar-YE', {
        year: 'numeric',
        month: '2-digit',
        day: '2-digit',
      }),
      formattedTime: dateObj.toLocaleTimeString('ar-YE', {
        hour: '2-digit',
        minute: '2-digit',
        hour12: true,
      }),
      status: branchId ? 'ASSIGNED' : 'UNASSIGNED',
      branchId: branchId || undefined,
      branchName: branchObj?.name,
      assignedAt: branchId ? dateObj.toISOString() : undefined,
      parsedMethod: overrideParsed ? 'AI' : 'REGEX',
      confidenceScore: parsed.confidenceScore || 90,
    };

    setTransactions([newTx, ...transactions]);

    if (branchId && branchObj) {
      showToast(`تمت إضافة الحوالة وتقييدها فوراً لفرع ${branchObj.name}`);
    } else {
      showToast(`تمت إضافة إشعار الرسالة بنجاح إلى صندوق المعلقة (غير المقيدة)`);
    }
  };

  // 5. Import multiple pasted SMS
  const handleImportParsedSmsList = (
    items: Array<{ rawSms: string; senderId: string; branchId?: string }>
  ) => {
    items.forEach((item) => {
      handleAddTransaction(item.rawSms, item.senderId, item.branchId);
    });
  };

  // 6. Delete Transaction
  const handleDeleteTransaction = (id: string) => {
    setTransactions((prev) => prev.filter((t) => t.id !== id));
    showToast('تم حذف الحوالة من السجل العام');
  };

  // 7. Add Branch
  const handleAddBranch = (
    branchData: Omit<Branch, 'id' | 'totalToday' | 'totalAllTime' | 'transactionCountToday'>
  ) => {
    const newBranch: Branch = {
      ...branchData,
      id: 'branch-' + Date.now(),
      totalToday: 0,
      totalAllTime: 0,
      transactionCountToday: 0,
    };
    setBranches([...branches, newBranch]);
    showToast(`تمت إضافة فرع "${newBranch.name}" بنجاح!`);
  };

  // 8. Edit Branch
  const handleEditBranch = (updatedBranch: Branch) => {
    setBranches(branches.map((b) => (b.id === updatedBranch.id ? updatedBranch : b)));
    showToast(`تم تحديث بيانات فرع "${updatedBranch.name}" بنجاح`);
  };

  // 9. Execute Daily Closeout
  const handleExecuteDailyCloseout = (notes: string) => {
    const dateStr = new Date().toISOString().split('T')[0];
    const unassigned = transactions.filter((t) => t.status === 'UNASSIGNED');
    const totalAmount = transactions.reduce((sum, t) => sum + t.amount, 0);
    const assignedAmount = transactions
      .filter((t) => t.status === 'ASSIGNED')
      .reduce((sum, t) => sum + t.amount, 0);

    const closeoutRecord: DailyCloseout = {
      id: 'closeout-' + Date.now(),
      date: dateStr,
      closedAt: new Date().toISOString(),
      totalWalletDeposits: totalAmount,
      totalAssignedToBranches: assignedAmount,
      unassignedAmount: unassigned.reduce((sum, t) => sum + t.amount, 0),
      totalTransactionsCount: transactions.length,
      unassignedCount: unassigned.length,
      branchBreakdown: branches.map((b) => {
        const bTxs = transactions.filter((t) => t.branchId === b.id);
        return {
          branchId: b.id,
          branchName: b.name,
          amount: bTxs.reduce((sum, t) => sum + t.amount, 0),
          count: bTxs.length,
        };
      }),
      closedBy: 'المدير العام',
      notes,
      status: unassigned.length === 0 ? 'RECONCILED' : 'NEEDS_AUDIT',
    };

    setCloseouts([closeoutRecord, ...closeouts]);
    showToast('تم إغلاق وتقفيل اليومية الحالية وتوثيق الحسابات في الأرشيف');
  };

  // 10. Export to CSV
  const handleExportCSV = () => {
    const headers = ['رقم الحوالة', 'المحفظة', 'المبلغ', 'اسم المحول', 'الفرع المقيد له', 'التاريخ', 'الوقت', 'الحالة'];
    const rows = transactions.map((t) => [
      t.transferRefNumber,
      t.providerName,
      t.amount,
      t.senderCustomerName || 'عام',
      t.branchName || 'غير مقيد',
      t.formattedDate,
      t.formattedTime,
      t.status === 'ASSIGNED' ? 'مقيدة' : 'معلقة',
    ]);

    const csvContent =
      'data:text/csv;charset=utf-8,\uFEFF' +
      [headers.join(','), ...rows.map((e) => e.join(','))].join('\n');

    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `كشف_حوالات_المحفظة_${new Date().toISOString().split('T')[0]}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  // 11. Reset Default Data
  const handleResetData = () => {
    if (confirm('هل أنت أثق من إعادة تعيين البيانات إلى الحالة الافتراضية؟')) {
      localStorage.removeItem('store_wallet_branches');
      localStorage.removeItem('store_wallet_transactions');
      localStorage.removeItem('store_wallet_providers');
      setBranches(INITIAL_BRANCHES);
      setTransactions(INITIAL_TRANSACTIONS);
      setProviders(DEFAULT_WALLET_PROVIDERS);
      showToast('تمت إعادة ضبط البيانات الافتراضية بنجاح');
    }
  };

  const unassignedTxs = transactions.filter((t) => t.status === 'UNASSIGNED');

  return (
    <div dir="rtl" className="min-h-screen bg-slate-950 text-slate-100 font-sans pb-16 antialiased selection:bg-emerald-500 selection:text-white">
      
      {/* Top Navigation */}
      <Navbar
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        transactions={transactions}
        onOpenSimulateModal={() => setIsSimulateModalOpen(true)}
        onOpenPasteModal={() => setIsPasteModalOpen(true)}
        onOpenScanModal={() => setIsScanModalOpen(true)}
        onOpenReconciliationModal={() => setActiveTab('reconciliation')}
      />

      {/* Main App Container */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-6">
        
        {/* DASHBOARD TAB (Combined view of pending queue + store branches) */}
        {activeTab === 'dashboard' && (
          <div className="space-y-8">
            
            {/* Quick Unassigned Pending Queue */}
            <UnassignedFeed
              unassignedTransactions={unassignedTxs}
              branches={branches}
              onAssignBranch={handleAssignBranch}
              onBulkAssignBranch={handleBulkAssignBranch}
              onSimulateNewSms={() => setIsSimulateModalOpen(true)}
            />

            {/* Quick Branch Overview Section */}
            <div className="space-y-4 pt-4 border-t border-slate-800">
              <div className="flex items-center justify-between">
                <h3 className="text-base font-bold text-white flex items-center gap-2">
                  <Building2 className="w-5 h-5 text-emerald-400" />
                  حسابات الفروع وإجمالي التحويلات المقيدة اليوم
                </h3>
                <button
                  onClick={() => setActiveTab('branches')}
                  className="text-xs font-semibold text-emerald-400 hover:underline"
                >
                  إدارة كافة الفروع ←
                </button>
              </div>

              <BranchesView
                branches={branches}
                transactions={transactions}
                onAddBranch={handleAddBranch}
                onEditBranch={handleEditBranch}
                onPrintBranchLedger={(b) => {
                  setIsPrintModalOpen(true);
                }}
              />
            </div>

          </div>
        )}

        {/* DEDICATED UNASSIGNED FEED TAB */}
        {activeTab === 'unassigned' && (
          <UnassignedFeed
            unassignedTransactions={unassignedTxs}
            branches={branches}
            onAssignBranch={handleAssignBranch}
            onBulkAssignBranch={handleBulkAssignBranch}
            onSimulateNewSms={() => setIsSimulateModalOpen(true)}
          />
        )}

        {/* STORE BRANCHES TAB */}
        {activeTab === 'branches' && (
          <BranchesView
            branches={branches}
            transactions={transactions}
            onAddBranch={handleAddBranch}
            onEditBranch={handleEditBranch}
            onPrintBranchLedger={(b) => {
              setIsPrintModalOpen(true);
            }}
          />
        )}

        {/* ALL TRANSACTIONS TABLE TAB */}
        {activeTab === 'all_transactions' && (
          <TransactionsTable
            transactions={transactions}
            branches={branches}
            onAssignBranch={handleAssignBranch}
            onDeleteTransaction={handleDeleteTransaction}
            onExportCSV={handleExportCSV}
          />
        )}

        {/* RECONCILIATION & CLOSEOUT TAB */}
        {activeTab === 'reconciliation' && (
          <ReconciliationView
            transactions={transactions}
            branches={branches}
            closeouts={closeouts}
            onExecuteDailyCloseout={handleExecuteDailyCloseout}
            onOpenPrintReport={() => setIsPrintModalOpen(true)}
          />
        )}

        {/* ANALYTICS & CHARTS TAB */}
        {activeTab === 'analytics' && (
          <AnalyticsView transactions={transactions} branches={branches} />
        )}

        {/* SETTINGS TAB */}
        {activeTab === 'settings' && (
          <SettingsModal
            providers={providers}
            onAddProvider={(p) => setProviders([...providers, p])}
            onDeleteProvider={(id) => setProviders(providers.filter((p) => p.id !== id))}
            onResetData={handleResetData}
          />
        )}

      </main>

      {/* Floating Action Toast Notification */}
      {toast && (
        <div className="fixed bottom-6 left-1/2 -translate-x-1/2 z-50 bg-slate-900 text-white px-5 py-3 rounded-2xl shadow-2xl border border-emerald-500/40 flex items-center gap-3 animate-in fade-in slide-in-from-bottom-4 duration-200">
          <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0" />
          <span className="text-xs font-semibold">{toast.message}</span>
          {toast.undoTxId && (
            <button
              onClick={handleUndoAssignment}
              className="px-2.5 py-1 bg-emerald-500/20 hover:bg-emerald-500/30 text-emerald-300 rounded-lg text-xs font-bold border border-emerald-500/30 flex items-center gap-1 transition-colors"
            >
              <RotateCcw className="w-3 h-3" />
              <span>تراجع</span>
            </button>
          )}
        </div>
      )}

      {/* Modals */}
      <SimulateSmsModal
        isOpen={isSimulateModalOpen}
        onClose={() => setIsSimulateModalOpen(false)}
        onAddTransaction={handleAddTransaction}
      />

      <PasteSmsModal
        isOpen={isPasteModalOpen}
        onClose={() => setIsPasteModalOpen(false)}
        branches={branches}
        onImportParsedSmsList={handleImportParsedSmsList}
      />

      <ScanSmsModal
        isOpen={isScanModalOpen}
        onClose={() => setIsScanModalOpen(false)}
        branches={branches}
        onAddTransactionWithBranch={handleAddTransaction}
      />

      <PrintDailyReportModal
        isOpen={isPrintModalOpen}
        onClose={() => setIsPrintModalOpen(false)}
        transactions={transactions}
        branches={branches}
      />

    </div>
  );
}
