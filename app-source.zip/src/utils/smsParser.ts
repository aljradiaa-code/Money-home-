import { SMSTransaction, WalletProviderRule } from '../types';

export const DEFAULT_WALLET_PROVIDERS: WalletProviderRule[] = [
  {
    id: 'jaib',
    name: 'محفظة جيب (Jaib)',
    senderId: 'jaib',
    color: 'emerald',
    logoText: 'جيب',
    active: true,
  },
  {
    id: 'kuraimi',
    name: 'حاسب الكريمي (Alkuraimi)',
    senderId: 'kuraimi',
    color: 'blue',
    logoText: 'الكريمي',
    active: true,
  },
  {
    id: 'jawali',
    name: 'محفظة جوالي (Jawali)',
    senderId: 'jawali',
    color: 'indigo',
    logoText: 'جوالي',
    active: true,
  },
  {
    id: 'onecash',
    name: 'وان كاش (OneCash)',
    senderId: 'onecash',
    color: 'amber',
    logoText: 'وان كاش',
    active: true,
  },
  {
    id: 'floosak',
    name: 'فلوسك (Floosak - BYK)',
    senderId: 'floosak',
    color: 'purple',
    logoText: 'فلوسك',
    active: true,
  },
  {
    id: 'tadhamon',
    name: 'تضامن باي (Tadhamon Pay)',
    senderId: 'tadhamon',
    color: 'sky',
    logoText: 'تضامن',
    active: true,
  },
];

export interface ParsedSmsResult {
  transferRefNumber: string;
  amount: number;
  currency: 'YER' | 'SAR' | 'USD';
  senderCustomerName?: string;
  customerPhone?: string;
  providerName: string;
  confidenceScore: number;
}

/**
 * Intelligent regex parser for SMS strings from various Yemeni and regional wallet providers
 */
export function parseSmsText(smsText: string, senderIdInput: string = 'jaib'): ParsedSmsResult {
  const text = smsText.trim();
  const lowerSender = senderIdInput.toLowerCase().trim();

  // Clean numbers (Arabic-Indic digits to Western digits: ٠١٢٣٤٥٦٧٨٩ -> 0123456789)
  const normalizedText = normalizeArabicDigits(text);

  let amount = 0;
  let transferRefNumber = '';
  let senderCustomerName = '';
  let customerPhone = '';
  let currency: 'YER' | 'SAR' | 'USD' = 'YER';
  let providerName = 'محفظة عامة';
  let confidenceScore = 70;

  // Detect Provider Name based on sender or text content
  if (lowerSender.includes('jaib') || text.includes('جيب') || lowerSender === 'jaib') {
    providerName = 'محفظة جيب';
  } else if (lowerSender.includes('kuraimi') || lowerSender.includes('alkuraimi') || text.includes('الكريمي') || text.includes('حاسب')) {
    providerName = 'حاسب الكريمي';
  } else if (lowerSender.includes('jawali') || text.includes('جوالي')) {
    providerName = 'محفظة جوالي';
  } else if (lowerSender.includes('onecash') || text.includes('وان كاش') || text.includes('ون كاش')) {
    providerName = 'وان كاش';
  } else if (lowerSender.includes('floosak') || text.includes('فلوسك')) {
    providerName = 'فلوسك';
  } else if (lowerSender.includes('tadhamon') || text.includes('تضامن')) {
    providerName = 'تضامن باي';
  }

  // Detect Currency
  if (normalizedText.includes('USD') || normalizedText.includes('دولار') || normalizedText.includes('$')) {
    currency = 'USD';
  } else if (normalizedText.includes('SAR') || normalizedText.includes('سعودي') || normalizedText.includes('ر.س')) {
    currency = 'SAR';
  } else {
    currency = 'YER';
  }

  // 1. Extract Amount
  // Matches expressions like:
  // "مبلغ 45,000" or "مبلغ 45000" or "مبلغ قدره 45,000 YER" or "45,000 ريال" or "إيداع 100000"
  const amountMatch =
    normalizedText.match(/(?:مبلغ|بمبلغ|قدره|إيداع|ايداع|استلمت|اضافة|إضافة|تم إضافة)\s*(?:قدره)?\s*:?\s*([0-9]{1,3}(?:,[0-9]{3})+|[0-9]+(?:\.[0-9]+)?)/i) ||
    normalizedText.match(/([0-9]{1,3}(?:,[0-9]{3})+|[0-9]+(?:\.[0-9]+)?)\s*(?:ريال|YER|SAR|USD|\$|ر\.ي|ر\.س)/i) ||
    normalizedText.match(/(?:مبلغ|بمبلغ)\s*:?\s*([0-9]+)/i);

  if (amountMatch && amountMatch[1]) {
    const rawAmt = amountMatch[1].replace(/,/g, '');
    const parsedAmt = parseFloat(rawAmt);
    if (!isNaN(parsedAmt) && parsedAmt > 0) {
      amount = parsedAmt;
    }
  }

  // 2. Extract Transfer Reference Number
  // Matches expressions like:
  // "رقم العملية: 98412304" or "مرجع العملية 45012984" or "رقم الحوالة: 8871243" or "رقم الإشعار: 334102" or "المرجع: 12345"
  const refMatch =
    normalizedText.match(/(?:رقم العملية|رقم الحوالة|مرجع العملية|رقم الإشعار|رقم الاشعار|المرجع|رقم القيد|مرجع|Ref|Txn|ID)\s*:?\s*([A-Za-z0-9_-]{5,20})/i) ||
    normalizedText.match(/#\s*([0-9]{5,18})/i) ||
    normalizedText.match(/(?:عملیة|عملية)\s*(?:رقم)?\s*:?\s*([0-9]{5,18})/i);

  if (refMatch && refMatch[1]) {
    transferRefNumber = refMatch[1];
    confidenceScore += 15;
  } else {
    // Fallback: search for any standalone number string with 6 to 14 digits
    const digitsMatch = normalizedText.match(/\b([0-9]{6,14})\b/);
    if (digitsMatch) {
      transferRefNumber = digitsMatch[1];
      confidenceScore += 5;
    } else {
      transferRefNumber = 'TXN-' + Math.floor(10000000 + Math.random() * 90000000);
    }
  }

  // 3. Extract Sender / Customer Name
  // Matches expressions like:
  // "المرسل: أحمد محمد" or "من: صالح عبدالله" or "العميل: سوبرماركت الخير" or "من الحساب: ..."
  const senderMatch =
    normalizedText.match(/(?:المرسل|العميل|من|من الحساب|بواسطة|اسم المحول)\s*:?\s*([\u0600-\u06FFa-zA-a-zA-Z\s]{3,30})(?:\.|\n|رقم|تاريخ|وقت|بمبلغ|في|$)/i);

  if (senderMatch && senderMatch[1]) {
    senderCustomerName = senderMatch[1].trim().replace(/\s+/g, ' ');
  }

  // 4. Extract Phone Number if present
  const phoneMatch = normalizedText.match(/\b(77[0-9]{7}|73[0-9]{7}|71[0-9]{7}|70[0-9]{7}|78[0-9]{7})\b/);
  if (phoneMatch && phoneMatch[1]) {
    customerPhone = phoneMatch[1];
  }

  if (amount > 0) confidenceScore += 15;

  return {
    transferRefNumber,
    amount,
    currency,
    senderCustomerName,
    customerPhone,
    providerName,
    confidenceScore: Math.min(confidenceScore, 98),
  };
}

export function normalizeArabicDigits(str: string): string {
  const arabicDigits = ['٠', '١', '٢', '٣', '٤', '٥', '٦', '٧', '٨', '٩'];
  return str.replace(/[٠-٩]/g, (w) => String(arabicDigits.indexOf(w)));
}

export function formatCurrency(amount: number, currency: string = 'YER'): string {
  const formatted = new Intl.NumberFormat('ar-YE', {
    maximumFractionDigits: 2,
  }).format(amount);

  let symbol = 'ر.ي';
  if (currency === 'SAR') symbol = 'ر.س';
  if (currency === 'USD') symbol = '$';

  return `${formatted} ${symbol}`;
}

export function formatDateTimeArabic(dateObj: Date = new Date()): { formattedDate: string; formattedTime: string } {
  const formattedDate = dateObj.toLocaleDateString('ar-YE', {
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
  });

  const formattedTime = dateObj.toLocaleTimeString('ar-YE', {
    hour: '2-digit',
    minute: '2-digit',
    hour12: true,
  });

  return { formattedDate, formattedTime };
}
