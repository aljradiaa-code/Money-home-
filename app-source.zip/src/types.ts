export type TransactionStatus = 'UNASSIGNED' | 'ASSIGNED' | 'FLAGGED' | 'REJECTED';

export type Currency = 'YER' | 'SAR' | 'USD';

export interface Branch {
  id: string;
  name: string;
  code: string;
  city: string;
  address?: string;
  managerName?: string;
  phone?: string;
  dailyTarget?: number;
  totalToday: number;
  totalAllTime: number;
  transactionCountToday: number;
  color: string;
}

export interface WalletProviderRule {
  id: string;
  name: string; // e.g. "محفظة جيب"
  senderId: string; // e.g. "jaib"
  regexPattern?: string;
  color: string;
  logoText: string;
  iconName?: string;
  active: boolean;
}

export interface SMSTransaction {
  id: string;
  rawSmsText: string;
  senderId: string; // e.g. "jaib"
  providerName: string; // e.g. "جيب"
  transferRefNumber: string; // e.g. "98412304"
  amount: number;
  currency: Currency;
  senderCustomerName?: string; // e.g. "أحمد محمد علي"
  customerPhone?: string;
  timestamp: string; // e.g. "2026-08-07T10:15:00"
  formattedDate: string; // e.g. "2026/08/07"
  formattedTime: string; // e.g. "10:15 صباحاً"
  status: TransactionStatus;
  branchId?: string; // Assigned store branch ID
  branchName?: string; // Assigned store branch name
  assignedAt?: string;
  notes?: string;
  assignedBy?: string;
  parsedMethod: 'REGEX' | 'AI' | 'MANUAL';
  confidenceScore?: number; // 0 - 100
}

export interface DailyCloseout {
  id: string;
  date: string; // YYYY-MM-DD
  closedAt: string;
  totalWalletDeposits: number;
  totalAssignedToBranches: number;
  unassignedAmount: number;
  totalTransactionsCount: number;
  unassignedCount: number;
  branchBreakdown: {
    branchId: string;
    branchName: string;
    amount: number;
    count: number;
  }[];
  closedBy: string;
  notes?: string;
  status: 'CLOSED' | 'RECONCILED' | 'NEEDS_AUDIT';
}

export interface SmsFilterState {
  searchQuery: string;
  senderId: string;
  branchId: string;
  status: string;
  dateFrom: string;
  dateTo: string;
  minAmount?: string;
  maxAmount?: string;
}
